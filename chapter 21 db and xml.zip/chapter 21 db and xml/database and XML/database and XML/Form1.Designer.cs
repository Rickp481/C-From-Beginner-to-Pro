﻿namespace database_and_XML
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customersGridView = new System.Windows.Forms.DataGridView();
            this.ordersGridView = new System.Windows.Forms.DataGridView();
            this.lineitemsGridView = new System.Windows.Forms.DataGridView();
            this.exportXML = new System.Windows.Forms.Button();
            this.importXML = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customersGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lineitemsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // customersGridView
            // 
            this.customersGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customersGridView.Location = new System.Drawing.Point(32, 32);
            this.customersGridView.Name = "customersGridView";
            this.customersGridView.Size = new System.Drawing.Size(588, 246);
            this.customersGridView.TabIndex = 0;
            // 
            // ordersGridView
            // 
            this.ordersGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ordersGridView.Location = new System.Drawing.Point(751, 32);
            this.ordersGridView.Name = "ordersGridView";
            this.ordersGridView.Size = new System.Drawing.Size(457, 246);
            this.ordersGridView.TabIndex = 1;
            // 
            // lineitemsGridView
            // 
            this.lineitemsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lineitemsGridView.Location = new System.Drawing.Point(32, 304);
            this.lineitemsGridView.Name = "lineitemsGridView";
            this.lineitemsGridView.Size = new System.Drawing.Size(1176, 246);
            this.lineitemsGridView.TabIndex = 2;
            // 
            // exportXML
            // 
            this.exportXML.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.exportXML.Location = new System.Drawing.Point(303, 587);
            this.exportXML.Name = "exportXML";
            this.exportXML.Size = new System.Drawing.Size(241, 66);
            this.exportXML.TabIndex = 3;
            this.exportXML.Text = "Export XML";
            this.exportXML.UseVisualStyleBackColor = true;
            this.exportXML.Click += new System.EventHandler(this.exportXML_Click);
            // 
            // importXML
            // 
            this.importXML.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.importXML.Location = new System.Drawing.Point(701, 587);
            this.importXML.Name = "importXML";
            this.importXML.Size = new System.Drawing.Size(241, 66);
            this.importXML.TabIndex = 4;
            this.importXML.Text = "Import XML";
            this.importXML.UseVisualStyleBackColor = true;
            this.importXML.Click += new System.EventHandler(this.importXML_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1263, 709);
            this.Controls.Add(this.importXML);
            this.Controls.Add(this.exportXML);
            this.Controls.Add(this.lineitemsGridView);
            this.Controls.Add(this.ordersGridView);
            this.Controls.Add(this.customersGridView);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lineitemsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView customersGridView;
        private System.Windows.Forms.DataGridView ordersGridView;
        private System.Windows.Forms.DataGridView lineitemsGridView;
        private System.Windows.Forms.Button exportXML;
        private System.Windows.Forms.Button importXML;
    }
}

