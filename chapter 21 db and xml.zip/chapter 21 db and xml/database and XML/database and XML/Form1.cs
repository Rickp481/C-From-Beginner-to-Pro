﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace database_and_XML
{
    public partial class Form1 : Form
    {
        private DataTable tblCustomers, tblOrders, tblLineitems;
        private SqlCommand myCommand;
        private SqlDataAdapter myDA0, myDA1, myDA2;

        private void exportXML_Click(object sender, EventArgs e)
        {
            // we have 3 options here single file, 3 separate files or a deep file
            // we will explore each
            // write_data_to_single_file();
            // write_three_separate_files();
            write_data_to_deep_file();
        }

        private void write_data_to_deep_file()
        {
            XmlDocument myDoc = new XmlDocument();
            XmlNode myRoot = myDoc.CreateElement("cust_ord_lineitems");
            myDoc.AppendChild(myRoot);

            XmlNode myCustomers = myDoc.CreateElement("customers");
            myRoot.AppendChild(myCustomers);

            foreach (DataGridViewRow myRow in customersGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myCustomer = myDoc.CreateElement("customer");
                    XmlAttribute myID = myDoc.CreateAttribute("customer_id");
                    myID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute myUpdateType1 = myDoc.CreateAttribute("update_type");
                    myUpdateType1.Value = "-1";
                    myCustomer.Attributes.Append(myUpdateType1);
                    myCustomer.Attributes.Append(myID);

                    myCustomers.AppendChild(myCustomer);

                    XmlElement first_name = myDoc.CreateElement("first_name");
                    first_name.InnerText = myRow.Cells[1].Value.ToString();
                    myCustomer.AppendChild(first_name);
                    XmlElement last_name = myDoc.CreateElement("last_name");
                    last_name.InnerText = myRow.Cells[2].Value.ToString();
                    myCustomer.AppendChild(last_name);
                    XmlElement email = myDoc.CreateElement("email");
                    email.InnerText = myRow.Cells[3].Value.ToString();
                    myCustomer.AppendChild(email);
                    XmlElement telephone = myDoc.CreateElement("telephone");
                    telephone.InnerText = myRow.Cells[4].Value.ToString();
                    myCustomer.AppendChild(telephone);

                    XmlNode myOrders = myDoc.CreateElement("orders");
                    myCustomer.AppendChild(myOrders);

                    foreach (DataGridViewRow myRow2 in ordersGridView.Rows)
                    {
                        if (myRow2.Cells[0].Value != null)
                        {
                            if (myRow.Cells[0].Value.ToString() == myRow2.Cells[2].Value.ToString())  // then this is a child to customer parent
                            {
                                XmlNode myOrder = myDoc.CreateElement("order");
                                XmlAttribute myCustID = myDoc.CreateAttribute("cust_id");
                                myCustID.Value = myRow2.Cells[2].Value.ToString();
                                XmlAttribute myOrdID = myDoc.CreateAttribute("order_id");
                                myOrdID.Value = myRow2.Cells[0].Value.ToString();
                                XmlAttribute myUpdateType2 = myDoc.CreateAttribute("update_type");
                                myUpdateType2.Value = "-1";
                                myOrder.Attributes.Append(myCustID);
                                myOrder.Attributes.Append(myOrdID);
                                myOrder.Attributes.Append(myUpdateType2);

                                myOrders.AppendChild(myOrder);

                                XmlElement myOrderDate = myDoc.CreateElement("order_date");
                                myOrderDate.InnerText = myRow2.Cells[1].Value.ToString();
                                myOrder.AppendChild(myOrderDate);

                                // now throw in the lineitems
                                XmlNode myLineItems = myDoc.CreateElement("lineitems");
                                myOrder.AppendChild(myLineItems);

                                foreach(DataGridViewRow myRow3 in lineitemsGridView.Rows)
                                {
                                    if (myRow3.Cells[0].Value != null)
                                    {
                                        if (myRow2.Cells[0].Value.ToString() == myRow3.Cells[0].Value.ToString())
                                        {
                                            XmlNode mylineitem = myDoc.CreateElement("lineitem");
                                            XmlAttribute myOrderID = myDoc.CreateAttribute("order_id");
                                            myOrderID.Value = myRow3.Cells[0].Value.ToString();
                                            XmlAttribute myline = myDoc.CreateAttribute("line");
                                            myline.Value = myRow3.Cells[1].Value.ToString();
                                            XmlAttribute myUpdateType3 = myDoc.CreateAttribute("update_type");
                                            myUpdateType3.Value = "-1";
                                            mylineitem.Attributes.Append(myOrderID);
                                            mylineitem.Attributes.Append(myline);
                                            mylineitem.Attributes.Append(myUpdateType3);

                                            myLineItems.AppendChild(mylineitem);

                                            XmlElement myproductid = myDoc.CreateElement("product_id");
                                            myproductid.InnerText = myRow3.Cells[2].Value.ToString();
                                            mylineitem.AppendChild(myproductid);
                                            XmlElement order_quantity = myDoc.CreateElement("order_quantity");
                                            order_quantity.InnerText = myRow3.Cells[3].Value.ToString();
                                            mylineitem.AppendChild(order_quantity);
                                            XmlElement extended_price = myDoc.CreateElement("extended_price");
                                            extended_price.InnerText = myRow3.Cells[4].Value.ToString();
                                            mylineitem.AppendChild(extended_price);
                                            XmlElement product_desc = myDoc.CreateElement("product_desc");
                                            product_desc.InnerText = myRow3.Cells[5].Value.ToString();
                                            mylineitem.AppendChild(product_desc);

                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            string myFileName = @"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\customer_orders.xml";
            if (File.Exists(myFileName)) File.Delete(myFileName);  // avoid  dups
            myDoc.Save(myFileName);
            MessageBox.Show("All grid data was written to customer_orders.xml");
        }

        private void importXML_Click(object sender, EventArgs e)
        {
            customersGridView.DataSource = null;
            ordersGridView.DataSource = null;
            lineitemsGridView.DataSource = null;

            //read_single_serialized_file();
            //read_three_files();
            read_deep_file();
        }

        private void read_deep_file()
        {
            XmlDocument myDoc = new XmlDocument();
            myDoc.Load(@"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\customer_orders.xml");

            XmlNodeList myCustomers = myDoc.GetElementsByTagName("customer");  // datasource is null now so we need to reconstruct
            customersGridView.Columns.Add("customer_id", "customer_id");
            customersGridView.Columns.Add("first_name", "first_name");
            customersGridView.Columns.Add("last_name", "last_name");
            customersGridView.Columns.Add("email", "email");
            customersGridView.Columns.Add("telephone", "telephone");
            customersGridView.Columns.Add("update_type", "update_type");
            foreach (XmlNode myNode in myCustomers)
            {
                int myIndex = customersGridView.Rows.Add();
                customersGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["customer_id"].Value.ToString();
                customersGridView.Rows[myIndex].Cells[1].Value = myNode["first_name"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[2].Value = myNode["last_name"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[3].Value = myNode["email"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[4].Value = myNode["telephone"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[5].Value = myNode.Attributes["update_type"].Value.ToString();
            }

            XmlNodeList myOrders = myDoc.GetElementsByTagName("order");
            ordersGridView.Columns.Add("order_id", "order_id");
            ordersGridView.Columns.Add("order_date", "order_date");
            ordersGridView.Columns.Add("customer_id", "customer_id");
            ordersGridView.Columns.Add("update_type", "update_type");

            foreach (XmlNode myNode in myOrders)
            {
                int myIndex = ordersGridView.Rows.Add();
                ordersGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["order_id"].Value.ToString();
                ordersGridView.Rows[myIndex].Cells[1].Value = myNode["order_date"].InnerText.ToString();
                ordersGridView.Rows[myIndex].Cells[2].Value = myNode.Attributes["cust_id"].Value.ToString();
                ordersGridView.Rows[myIndex].Cells[3].Value = myNode.Attributes["update_type"].Value.ToString();
            }

            XmlNodeList myLineItems = myDoc.GetElementsByTagName("lineitem");
            lineitemsGridView.Columns.Add("order_id", "order_id");
            lineitemsGridView.Columns.Add("lineitem", "lineitem");
            lineitemsGridView.Columns.Add("product_id", "product_id");
            lineitemsGridView.Columns.Add("order_quantity", "order_quantity");
            lineitemsGridView.Columns.Add("extended_price", "extended_price");
            lineitemsGridView.Columns.Add("product_desc", "product_desc");
            lineitemsGridView.Columns.Add("update_type", "update_type");

            foreach (XmlNode myNode in myLineItems)
            {
                int myIndex = lineitemsGridView.Rows.Add();
                lineitemsGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["order_id"].Value.ToString();
                lineitemsGridView.Rows[myIndex].Cells[1].Value = myNode.Attributes["line"].Value.ToString();
                lineitemsGridView.Rows[myIndex].Cells[2].Value = myNode["product_id"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[3].Value = myNode["order_quantity"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[4].Value = myNode["extended_price"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[5].Value = myNode["product_desc"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[6].Value = myNode.Attributes["update_type"].Value.ToString();
            }

        }

        private void read_three_files()
        {
            XmlDocument myDoc = new XmlDocument();
            myDoc.Load(@"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\customers.xml");

            XmlNodeList myCustomers = myDoc.GetElementsByTagName("customer");
            customersGridView.Columns.Add("customer_id", "customer_id");
            customersGridView.Columns.Add("first_name", "first_name");
            customersGridView.Columns.Add("last_name", "last_name");
            customersGridView.Columns.Add("email", "email");
            customersGridView.Columns.Add("telephone", "telephone");
            customersGridView.Columns.Add("update_type", "update_type");

            foreach (XmlNode myNode in myCustomers)
            {
                int myIndex = customersGridView.Rows.Add();
                customersGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["customer_id"].Value.ToString();
                customersGridView.Rows[myIndex].Cells[1].Value = myNode["first_name"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[2].Value = myNode["last_name"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[3].Value = myNode["email"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[4].Value = myNode["telephone"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[5].Value = myNode.Attributes["update_type"].Value.ToString();
            }

            myDoc.Load(@"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\orders.xml");
            XmlNodeList myOrders = myDoc.GetElementsByTagName("order");
            ordersGridView.Columns.Add("order_id", "order_id");
            ordersGridView.Columns.Add("order_date", "order_date");
            ordersGridView.Columns.Add("customer_id", "customer_id");
            ordersGridView.Columns.Add("update_type", "update_type");

            foreach (XmlNode myNode in myOrders)
            {
                int myIndex = ordersGridView.Rows.Add();
                ordersGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["order_id"].Value.ToString();
                ordersGridView.Rows[myIndex].Cells[1].Value = myNode["order_date"].InnerText.ToString();
                ordersGridView.Rows[myIndex].Cells[2].Value = myNode.Attributes["cust_id"].Value.ToString();
                ordersGridView.Rows[myIndex].Cells[3].Value = myNode.Attributes["update_type"].Value.ToString();
            }

            myDoc.Load(@"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\lineitems.xml");
            XmlNodeList myLineItems = myDoc.GetElementsByTagName("lineitem");
            lineitemsGridView.Columns.Add("order_id", "order_id");
            lineitemsGridView.Columns.Add("lineitem", "lineitem");
            lineitemsGridView.Columns.Add("product_id", "product_id");
            lineitemsGridView.Columns.Add("order_quantity", "order_quantity");
            lineitemsGridView.Columns.Add("extended_price", "extended_price");
            lineitemsGridView.Columns.Add("product_desc", "product_desc");
            lineitemsGridView.Columns.Add("update_type", "update_type");

            foreach (XmlNode myNode in myLineItems)
            {
                int myIndex = lineitemsGridView.Rows.Add();
                lineitemsGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["order_id"].Value.ToString();
                lineitemsGridView.Rows[myIndex].Cells[1].Value = myNode.Attributes["lineitem"].Value.ToString();
                lineitemsGridView.Rows[myIndex].Cells[2].Value = myNode["product_id"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[3].Value = myNode["order_quantity"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[4].Value = myNode["extended_price"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[5].Value = myNode["product_desc"].InnerText.ToString();  // don't need this back in db
                lineitemsGridView.Rows[myIndex].Cells[6].Value = myNode.Attributes["update_type"].Value.ToString();
            }
        }

        private void read_single_serialized_file()
        {
            XmlDocument myDoc = new XmlDocument();
            myDoc.Load(@"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\single_file.xml");

            XmlNodeList myCustomers = myDoc.GetElementsByTagName("customer");  // datasource is null now so we need to reconstruct
            customersGridView.Columns.Add("customer_id", "customer_id");
            customersGridView.Columns.Add("first_name", "first_name");
            customersGridView.Columns.Add("last_name", "last_name");
            customersGridView.Columns.Add("email", "email");
            customersGridView.Columns.Add("telephone", "telephone");
            customersGridView.Columns.Add("update_type", "update_type");
            foreach (XmlNode myNode in myCustomers)
            {
                int myIndex = customersGridView.Rows.Add();
                customersGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["customer_id"].Value.ToString();
                customersGridView.Rows[myIndex].Cells[1].Value = myNode["first_name"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[2].Value = myNode["last_name"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[3].Value = myNode["email"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[4].Value = myNode["telephone"].InnerText.ToString();
                customersGridView.Rows[myIndex].Cells[5].Value = myNode.Attributes["update_type"].Value.ToString();
            }

            XmlNodeList myOrders = myDoc.GetElementsByTagName("order");
            ordersGridView.Columns.Add("order_id", "order_id");
            ordersGridView.Columns.Add("order_date", "order_date");
            ordersGridView.Columns.Add("customer_id", "customer_id");
            ordersGridView.Columns.Add("update_type", "update_type");

            foreach (XmlNode myNode in myOrders)
            {
                int myIndex = ordersGridView.Rows.Add();
                ordersGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["order_id"].Value.ToString();
                ordersGridView.Rows[myIndex].Cells[1].Value = myNode["order_date"].InnerText.ToString();
                ordersGridView.Rows[myIndex].Cells[2].Value = myNode.Attributes["cust_id"].Value.ToString();
                ordersGridView.Rows[myIndex].Cells[3].Value = myNode.Attributes["update_type"].Value.ToString();
            }

            XmlNodeList myLineItems = myDoc.GetElementsByTagName("lineitem");
            lineitemsGridView.Columns.Add("order_id","order_id");
            lineitemsGridView.Columns.Add("lineitem", "lineitem");
            lineitemsGridView.Columns.Add("product_id", "product_id");
            lineitemsGridView.Columns.Add("order_quantity", "order_quantity");
            lineitemsGridView.Columns.Add("extended_price", "extended_price");
            lineitemsGridView.Columns.Add("product_desc", "product_desc");
            lineitemsGridView.Columns.Add("update_type", "update_type");

            foreach(XmlNode myNode in myLineItems)
            {
                int myIndex = lineitemsGridView.Rows.Add();
                lineitemsGridView.Rows[myIndex].Cells[0].Value = myNode.Attributes["order_id"].Value.ToString();
                lineitemsGridView.Rows[myIndex].Cells[1].Value = myNode.Attributes["lineitem"].Value.ToString();
                lineitemsGridView.Rows[myIndex].Cells[2].Value = myNode["product_id"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[3].Value = myNode["order_quantity"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[4].Value = myNode["extended_price"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[5].Value = myNode["product_desc"].InnerText.ToString();
                lineitemsGridView.Rows[myIndex].Cells[6].Value = myNode.Attributes["update_type"].Value.ToString();
            }
        }

        private void write_three_separate_files()
        {
            XmlDocument myDoc = new XmlDocument();
            XmlNode myRoot = myDoc.CreateElement("customers");
            myDoc.AppendChild(myRoot);

            foreach (DataGridViewRow myRow in customersGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myCustomer = myDoc.CreateElement("customer");
                    XmlAttribute myID = myDoc.CreateAttribute("customer_id");
                    myID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute myUpdateType = myDoc.CreateAttribute("update_type");
                    myUpdateType.Value = "-1";
                    myCustomer.Attributes.Append(myID);
                    myCustomer.Attributes.Append(myUpdateType);

                    myRoot.AppendChild(myCustomer);

                    XmlElement first_name = myDoc.CreateElement("first_name");
                    first_name.InnerText = myRow.Cells[1].Value.ToString();
                    myCustomer.AppendChild(first_name);
                    XmlElement last_name = myDoc.CreateElement("last_name");
                    last_name.InnerText = myRow.Cells[2].Value.ToString();
                    myCustomer.AppendChild(last_name);
                    XmlElement email = myDoc.CreateElement("email");
                    email.InnerText = myRow.Cells[3].Value.ToString();
                    myCustomer.AppendChild(email);
                    XmlElement telephone = myDoc.CreateElement("telephone");
                    telephone.InnerText = myRow.Cells[4].Value.ToString();
                    myCustomer.AppendChild(telephone);
                }
            }

            string myFileName = @"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\customers.xml";
            if (File.Exists(myFileName)) File.Delete(myFileName);  // avoid  dups
            myDoc.Save(myFileName);

            XmlDocument myDoc2 = new XmlDocument();
            XmlNode myRoot2 = myDoc2.CreateElement("orders");
            myDoc2.AppendChild(myRoot2);

            foreach (DataGridViewRow myRow in ordersGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myOrder = myDoc2.CreateElement("order");
                    XmlAttribute myCustID = myDoc2.CreateAttribute("cust_id");
                    myCustID.Value = myRow.Cells[2].Value.ToString();
                    XmlAttribute myOrdID = myDoc2.CreateAttribute("order_id");
                    myOrdID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute myUpdateType = myDoc2.CreateAttribute("update_type");
                    myUpdateType.Value = "-1";
                    myOrder.Attributes.Append(myCustID);
                    myOrder.Attributes.Append(myOrdID);
                    myOrder.Attributes.Append(myUpdateType);

                    myRoot2.AppendChild(myOrder);

                    XmlElement myOrderDate = myDoc2.CreateElement("order_date");
                    myOrderDate.InnerText = myRow.Cells[1].Value.ToString();
                    myOrder.AppendChild(myOrderDate);
                }
            }

            string myFileName2 = @"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\orders.xml";
            if (File.Exists(myFileName2)) File.Delete(myFileName2);  // avoid  dups
            myDoc2.Save(myFileName2);

            XmlDocument myDoc3 = new XmlDocument();
            XmlNode myRoot3 = myDoc3.CreateElement("lineitems");
            myDoc3.AppendChild(myRoot3);

            foreach (DataGridViewRow myRow in lineitemsGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myLineItem = myDoc3.CreateElement("lineitem");
                    XmlAttribute myOrdID = myDoc3.CreateAttribute("order_id");
                    myOrdID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute mylineitem = myDoc3.CreateAttribute("lineitem");
                    mylineitem.Value = myRow.Cells[1].Value.ToString();
                    XmlAttribute myUpdateType = myDoc3.CreateAttribute("update_type");
                    myUpdateType.Value = "-1";
                    myLineItem.Attributes.Append(myOrdID);
                    myLineItem.Attributes.Append(mylineitem);
                    myLineItem.Attributes.Append(myUpdateType);

                    myRoot3.AppendChild(myLineItem);

                    XmlElement product_id = myDoc3.CreateElement("product_id");
                    product_id.InnerText = myRow.Cells[2].Value.ToString();
                    myLineItem.AppendChild(product_id);
                    XmlElement order_quantity = myDoc3.CreateElement("order_quantity");
                    order_quantity.InnerText = myRow.Cells[3].Value.ToString();
                    myLineItem.AppendChild(order_quantity);
                    XmlElement extended_price = myDoc3.CreateElement("extended_price");
                    extended_price.InnerText = myRow.Cells[4].Value.ToString();
                    myLineItem.AppendChild(extended_price);
                    XmlElement product_desc = myDoc3.CreateElement("product_desc");
                    product_desc.InnerText = myRow.Cells[5].Value.ToString();
                    myLineItem.AppendChild(product_desc);
                }
            }

            string myFileName3 = @"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\lineitems.xml";
            if (File.Exists(myFileName3)) File.Delete(myFileName3);  // avoid  dups
            myDoc3.Save(myFileName3);

            MessageBox.Show("customers.xml orders.xml and lineitems.xml have all been created.");
        }

        private void write_data_to_single_file()
        {
            XmlDocument myDoc = new XmlDocument();

            // start with the customers table
            XmlNode myRoot = myDoc.CreateElement("customer_orders");
            myDoc.AppendChild(myRoot);
            XmlNode myCustomers = myDoc.CreateElement("customers");
            myRoot.AppendChild(myCustomers);
            
            foreach (DataGridViewRow myRow in customersGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myCustomer = myDoc.CreateElement("customer");
                    XmlAttribute myID = myDoc.CreateAttribute("customer_id");
                    myID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute myUpdateType = myDoc.CreateAttribute("update_type");
                    myUpdateType.Value = "-1";
                    myCustomer.Attributes.Append(myID);
                    myCustomer.Attributes.Append(myUpdateType);

                    myCustomers.AppendChild(myCustomer);

                    XmlElement first_name = myDoc.CreateElement("first_name");
                    first_name.InnerText = myRow.Cells[1].Value.ToString();
                    myCustomer.AppendChild(first_name);
                    XmlElement last_name = myDoc.CreateElement("last_name");
                    last_name.InnerText = myRow.Cells[2].Value.ToString();
                    myCustomer.AppendChild(last_name);
                    XmlElement email = myDoc.CreateElement("email");
                    email.InnerText = myRow.Cells[3].Value.ToString();
                    myCustomer.AppendChild(email);
                    XmlElement telephone = myDoc.CreateElement("telephone");
                    telephone.InnerText = myRow.Cells[4].Value.ToString();
                    myCustomer.AppendChild(telephone);        
                }
            }

            // now add in orders
            XmlNode myOrders = myDoc.CreateElement("orders");
            myRoot.AppendChild(myOrders);

            foreach (DataGridViewRow myRow in ordersGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myOrder = myDoc.CreateElement("order");
                    XmlAttribute myCustID = myDoc.CreateAttribute("cust_id");
                    myCustID.Value = myRow.Cells[2].Value.ToString();
                    XmlAttribute myOrdID = myDoc.CreateAttribute("order_id");
                    myOrdID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute myUpdateType = myDoc.CreateAttribute("update_type");
                    myUpdateType.Value = "-1";
                    myOrder.Attributes.Append(myCustID);
                    myOrder.Attributes.Append(myOrdID);
                    myOrder.Attributes.Append(myUpdateType);

                    myOrders.AppendChild(myOrder);

                    XmlElement myOrderDate = myDoc.CreateElement("order_date");
                    myOrderDate.InnerText = myRow.Cells[1].Value.ToString();
                    myOrder.AppendChild(myOrderDate);
                }
            }

            // lineitems
            XmlNode myLineItems = myDoc.CreateElement("lineitems");
            myRoot.AppendChild(myLineItems);

            foreach (DataGridViewRow myRow in lineitemsGridView.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    XmlNode myLineItem = myDoc.CreateElement("lineitem");
                    XmlAttribute myOrdID = myDoc.CreateAttribute("order_id");
                    myOrdID.Value = myRow.Cells[0].Value.ToString();
                    XmlAttribute mylineitem = myDoc.CreateAttribute("lineitem");
                    mylineitem.Value = myRow.Cells[1].Value.ToString();
                    XmlAttribute myUpdateType = myDoc.CreateAttribute("update_type");
                    myUpdateType.Value = "-1";
                    myLineItem.Attributes.Append(myOrdID);
                    myLineItem.Attributes.Append(mylineitem);
                    myLineItem.Attributes.Append(myUpdateType);

                    myLineItems.AppendChild(myLineItem);

                    XmlElement product_id = myDoc.CreateElement("product_id");
                    product_id.InnerText = myRow.Cells[2].Value.ToString();
                    myLineItem.AppendChild(product_id);
                    XmlElement order_quantity = myDoc.CreateElement("order_quantity");
                    order_quantity.InnerText = myRow.Cells[3].Value.ToString();
                    myLineItem.AppendChild(order_quantity);
                    XmlElement extended_price = myDoc.CreateElement("extended_price");
                    extended_price.InnerText = myRow.Cells[4].Value.ToString();
                    myLineItem.AppendChild(extended_price);
                    XmlElement product_desc = myDoc.CreateElement("product_desc");
                    product_desc.InnerText = myRow.Cells[5].Value.ToString();
                    myLineItem.AppendChild(product_desc);
                }
            }

            // write this guy out to disk
            string myFileName = @"D:\documents\C# From Beginner to Pro\chapter 21 database and XML\single_file.xml";
            if (File.Exists(myFileName)) File.Delete(myFileName);  // avoid  dups
            myDoc.Save(myFileName);
            MessageBox.Show("single_file.xml successfully written to disk");

        }
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            DataTable tblCustomers = new DataTable("tblCustomers");
            DataTable tblOrders = new DataTable("tblOrders");
            DataTable tblLineitems = new DataTable("tblLineitems");

            SqlConnection myCon = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");
            myCon.Open();

            myCommand = new SqlCommand("readCustomers", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("cust_id", -1);  // read them all
            myDA0 = new SqlDataAdapter(myCommand);
            myDA0.Fill(tblCustomers);
            customersGridView.DataSource = tblCustomers;

            myCommand = new SqlCommand("readOrders", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("cust_id", -1); 
            myCommand.Parameters.AddWithValue("ord_id",-1);
            myDA1 = new SqlDataAdapter(myCommand);
            myDA1.Fill(tblOrders);
            ordersGridView.DataSource = tblOrders;

            myCommand = new SqlCommand("readLineItems", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("ord_id", -1);
            myDA2 = new SqlDataAdapter(myCommand);
            myDA2.Fill(tblLineitems);
            lineitemsGridView.DataSource = tblLineitems;

            myCon.Close();
        }
    }
}
