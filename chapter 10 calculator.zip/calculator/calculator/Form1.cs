﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace calculator
{
    public partial class Form1 : Form
    {
        string operand1, operand2, my_operator;
        double my_result;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            operand1 = null;
            operand2 = null;
            my_operator = null;
            DisplayLabel.Text = "0";
            my_result = 0;
        }

        private bool is_too_long()
        {
            if (DisplayLabel.Text.Length >= 23)
            {
                Console.Beep();
                MessageBox.Show("You rnumber is too long for the display", "Too long");
                return true;
            }
            else return false;
        }

        private void concatenate_display (string x)
        {
            if (is_too_long())
            {
                // the user was just informed that their operand was too long, go back to defaults
                operand1 = null;
                operand2 = null;
                my_operator = null;
                DisplayLabel.Text = "0";
            }
            else if (DisplayLabel.Text != "0" && DisplayLabel.Text != operand1)
            {
                // user is forming a multi-digit number, just concatenate the input parm
                DisplayLabel.Text += x;
            }
            else // user is entering the first digit of an operand
                DisplayLabel.Text = x;
        }

        private void GenericNumberButton_Click(object sender, EventArgs e)
        {
            Button btn = (Button)sender;  // we know it will be a button because we will only attach to buttons
            concatenate_display(btn.Text);
        }

        private void ClearButton_Click(object sender, EventArgs e)
        {
            operand1 = null;
            operand2 = null;
            DisplayLabel.Text = "0";
        }

        private void ClearEntryButtton_Click(object sender, EventArgs e)
        {
            DisplayLabel.Text = "0";
        }

        private void ChangeSignButton_Click(object sender, EventArgs e)
        {
            DisplayLabel.Text = (-1 * Convert.ToDouble(DisplayLabel.Text)).ToString();
        }

        private void PercentButton_Click(object sender, EventArgs e)
        {
            if (DisplayLabel.Text.IndexOf("%") > 0) MessageBox.Show("Value is already in percentile format.");
            else DisplayLabel.Text = (100 * Convert.ToDouble(DisplayLabel.Text)).ToString() + "%";
        }

        private void updateSkinToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (openFileDialog1.ShowDialog() == DialogResult.OK)  // this will occur when user hits ok button on dialog
                pictureBox1.Load(openFileDialog1.FileName);
        }

        private void updateDisplayColorToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        public double calculate_result()
        {

            if (my_operator == "+")
            {
                my_result = Convert.ToDouble(operand1) + Convert.ToDouble(operand2);
            }
            else if (my_operator == "-")
            {
                my_result = Convert.ToDouble(operand1) - Convert.ToDouble(operand2);
            }
            else if (my_operator == "*")
            {
                my_result = Convert.ToDouble(operand1) * Convert.ToDouble(operand2);
            }
            else if (my_operator == "/")
            {
                my_result = Convert.ToDouble(operand1) / Convert.ToDouble(operand2);
            }
            return my_result;
        }

        private void GenericOperatorButton_Click (object sender, EventArgs e)
        {

            Button btn = (Button)sender;
            string this_operator = btn.Text;

            if (operand1 == null)
            {
                // grab the first operand and reset to defaults
                operand1 = DisplayLabel.Text;
                operand2 = null;
                DisplayLabel.Text = "0";
                my_operator = this_operator;
            }
            else if (this_operator == "=")
            {
                // user has hit equals sign
                operand2 = DisplayLabel.Text;
                operand1 = calculate_result().ToString();
                DisplayLabel.Text = operand1;
                operand2 = null;
                my_operator = null;
            }
            {
                // user is stringing together operators
                operand2 = DisplayLabel.Text;
                operand1 = calculate_result().ToString();
                DisplayLabel.Text = operand1;
                operand2 = null;
                my_operator = this_operator;
            }
        }

    }
}
