﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace movement
{
    public partial class Form1 : Form
    {
        enum Directions {Up, Down, Left, Right, Clockwise, Bigger, Smaller};
        enum Controller {Button, Keyboard, MouseLeft};
        enum Changing {Size, Location, Rotation};

        Directions direction;
        Controller controller;
        Changing changing;

        int FormHeight = 600;
        int FormWidth = 1200;
        int x_location = 525;
        int y_location = 225;

        Random ran = new Random();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // in our initial example we will adjust the size of our image
            direction = Directions.Bigger;
            controller = Controller.MouseLeft;
            changing = Changing.Rotation;

            if (changing == Changing.Location) PickDirection();
            
            if (changing == Changing.Rotation)
            {
                pictureBox1.Size = new Size(200, 200);
                Image img = Image.FromFile(@"D:\documents\C# From Beginner to Pro\chapter 13 movement\images\wheel image.jpg");
                pictureBox1.Image = img;
                StartStopButton.Visible = false;
                timer1.Enabled = true;
            }
            else if (controller == Controller.Button)
            {
                StartStopButton.Text = "Start";
                timer1.Enabled = false;
                StartStopButton.Visible = true;
            }
            else if (controller == Controller.Keyboard)
            {
                StartStopButton.Text = "Start";
                timer1.Enabled = true;
                StartStopButton.Visible = false;
            }
            else if (controller == Controller.MouseLeft)
            {
                StartStopButton.Text = "Start";
                timer1.Enabled = false;
                StartStopButton.Visible = false;
            }

            pictureBox1.Size = new Size(50, 50);
            pictureBox1.Location = new Point(x_location, y_location);
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (changing == Changing.Size)  // we are going to move that guy Bigger and Smaller
            {
                pictureBox1.Location = new Point(10, 10);
                if (direction == Directions.Bigger) ChangeSizeBigger();
                else ChangeSizeSmaller();
            }
            else if (changing == Changing.Location) ChangeLocation();
            else if (changing == Changing.Rotation) SpinSomething();
        }

        private void SpinSomething()
        {
            Image img = new Bitmap(pictureBox1.Image);
            img.RotateFlip(RotateFlipType.Rotate90FlipNone);    // spin it 90%
            pictureBox1.Image = img;
        }

        private void PickDirection()
        {
            int r = ran.Next(4);    // 0=Left, 1=Right, 2=Up, 3=Down
            if (r == 0) direction = Directions.Left;
            if (r == 1) direction = Directions.Right;
            if (r == 2) direction = Directions.Up;
            if (r == 3) direction = Directions.Down;
        }

        private void ChangeLocation()
        {
            if (direction == Directions.Left)
            {
                if (x_location > 10)
                {
                    x_location -= 10;
                    pictureBox1.Left = x_location;
                } else PickDirection();
            } else if (direction == Directions.Right)
            {
                if (x_location + 10 < FormWidth - 70)
                {
                    x_location += 10;
                    pictureBox1.Left = x_location;
                } else PickDirection();
            } else if (direction == Directions.Up)
            {
                if (y_location > 10)
                {
                    y_location -= 10;
                    pictureBox1.Top = y_location;
                } else PickDirection();
            } else if (direction == Directions.Down)
            {
                if (y_location < FormHeight - 90)
                {
                    y_location += 10;
                    pictureBox1.Top = y_location;
                } else PickDirection();
            }
            else if (controller == Controller.Keyboard)
            {
                if (direction == Directions.Left && x_location >= 20) x_location -= 10;
                else if (direction == Directions.Right && x_location <= FormWidth - 50 - 20) x_location += 10;
                else if (direction == Directions.Up && y_location >= 20) y_location -= 10;
                else if (direction == Directions.Down && y_location <= FormHeight - 50 - 20) y_location += 10;
            }
        }

        private void Form1_KeyDown(object sender, KeyEventArgs e)   // note the use of KeyEventArgs class
        {
            if (e.KeyCode == Keys.Left) direction = Directions.Left;
            else if (e.KeyCode == Keys.Right) direction = Directions.Right;
            else if (e.KeyCode == Keys.Up) direction = Directions.Up;
            else if (e.KeyCode == Keys.Down) direction = Directions.Down;
        }

        private void ChangeSizeBigger()
        {
            if (pictureBox1.Height < FormHeight && pictureBox1.Width < FormWidth)
                pictureBox1.Size = new Size(pictureBox1.Width + 20, pictureBox1.Height + 8);
            else direction = Directions.Smaller;
        }

        private void ChangeSizeSmaller()
        {
            if (pictureBox1.Height > 10 && pictureBox1.Width > 10)
            {
                pictureBox1.Height -= 8;
                pictureBox1.Width -= 20;
            }
            else direction = Directions.Bigger;
        }

        private void StartStopButton_Click(object sender, EventArgs e)
        {
            if (StartStopButton.Text == "Start")
            {
                timer1.Enabled = true;
                StartStopButton.Text = "Stop";
            }
            else
            {
                timer1.Enabled = false;
                StartStopButton.Text = "Start";
            }
        }

        private void Form1_MouseDown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left && controller == Controller.MouseLeft)
            {
                pictureBox1.Left = e.X;
                pictureBox1.Top = e.Y;
            }
        }
    }
}
