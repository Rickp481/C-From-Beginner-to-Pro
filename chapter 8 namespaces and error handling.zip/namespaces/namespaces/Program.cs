﻿using System;
using static System.Console;

namespace namespaces
{
    namespace myNamespace
    {
        public class Person
        {
            public Person()
            {
                WriteLine("Inside myNamespace.Person constructor");
            }

            public void PersonMethod()
            {
                WriteLine("Inside myNamespace.PersonMethod");
            }
        }

        public class AgeIsZero : Exception          // user-defined exception 
        {
            public AgeIsZero(string message) : base(message) { }
        }

        public class Age
        {
            public void showAge(int myAge)
            {
                if (myAge == 0)
                    throw (new AgeIsZero("Age must be greater than zero."));
                else
                    WriteLine("Inside showAge = {0}", myAge);
            }
        }
    }
        namespace yourNamespace
        {
        public class Person
        {
            public Person()
            {
                WriteLine("Inside yourNamespace.Person constructor");
            }

            public void PersonMethod()
            {
                WriteLine("Inside yourNamespace.PersonMethod");
            }
        }

    }



    class Program
    {
        static void Main(string[] args)
        {
            myNamespace.Person p1 = new myNamespace.Person();
            yourNamespace.Person p2 = new yourNamespace.Person();

            p1.PersonMethod();
            p2.PersonMethod();

            // System defined error handling
            int[] myArray = new int[10];

            for (int lcv=0; lcv<11; lcv++)
            {
                try // this is the code which might fail
                {
                    // this will work for valid indices
                    myArray[lcv] = lcv;
                    WriteLine("Just successfully assigned {0} to myArray[{1}]", lcv, lcv);
                }
                catch (IndexOutOfRangeException e)  // this is the code which executes if try block threw an error
                {
                    // catch this System defined error
                    WriteLine("An error of type {0} has occurred on lcv = {1}", e, lcv);
                }
            }

            myNamespace.Age myAge = new myNamespace.Age();
            int i = 10;

            try
            {
                WriteLine("Age = {0}", i);
                myAge.showAge(i);
                
            }
            catch (myNamespace.AgeIsZero e)
            {
                WriteLine("Exception {0}", e.Message);
            }

            i = 0;
            try
            {
                WriteLine("Age = {0}", i);
                myAge.showAge(i);

            }
            catch (myNamespace.AgeIsZero e)
            {
                WriteLine("Exception {0}", e.Message);
            }

            ReadLine();
        }
    }
}
