﻿using System;

namespace inheritance
{
    class Program
    {
        public class ParentClass
        {
            public string parent_property1, parent_property2;

            public ParentClass(string Property1, string Property2)
            {
                parent_property1 = Property1;
                parent_property2 = Property2;
            }

            public void Method1()
            {
                Console.WriteLine("I am ParentClass Method1");
            }
        }

        public class ChildClass : ParentClass
        {
            public string child_property1;

            public ChildClass(string prop1, string prop2, string prop3) : base(prop1,prop2)
            {
                child_property1 = prop3;
                Console.WriteLine("I am the ChildClass constructor method");
            }

            public void Method2()
            {
                Console.WriteLine("I am ChildClass Method2");
            }
        }

        static void Main(string[] args)
        {
            ChildClass c1 = new ChildClass("Hello", "World", "Rick is the code master");
            c1.Method1();
            c1.Method2();

            Console.WriteLine("{0} {1} {2}", c1.parent_property1, c1.parent_property2, c1.child_property1);

            Console.ReadLine();
        }
    }
}
