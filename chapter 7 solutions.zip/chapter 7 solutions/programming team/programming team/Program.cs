﻿using System;

namespace programming_team
{
    public class Person
    {
        private int i;  // ID
        private string fn, ln, g;   // first name, last name, gender

        public Person
            (
                int EmployeeID = -1,
                string FirstName = "Not Specified",
                string LastName = "Not Specified",
                string Gender = "Not Specified"
            )
        {
            if (FirstName.Equals("Not Specified") || LastName.Equals("Not Specified") || EmployeeID < 0)
            {
                // throw an error because each of those properties is required
                Console.WriteLine("Throwing an exception because a required field was missing");
                Console.ReadLine();
            }
            else if (Gender.Equals("Male") || Gender.Equals("Female"))
            {
                i = EmployeeID;
                fn = FirstName;
                ln = LastName;
                g = Gender;
            }
            else
            {
                // throw an error because gender value is invalid
                Console.WriteLine("Throwing an exception because gender value is invalid");
                Console.ReadLine();
            }
        }
        public int getEmployeeID()
        {
            return i;
        }

        public string getFirstName()
        {
            return fn;
        }

        public string getLastName()
        {
            return ln;
        }

        public string getGender()
        {
            return g;
        }
    }
    public class ProgrammingExperience
    {
        private string p1;
        private int nowYr;
        private DateTime now;

        public string ProgrammingLanguage  // shortcut syntax for get and set methods for this property
        {
            get { return p1; }
            set { p1 = value; }
        }

        public int YrStarted { get; set; }    // super shortcut syntax for get and set methods
        public int YrEnded { get; set; }

        public int YearsExperience
        {
            get
            {
                if (this.YrEnded * this.YrStarted > 0)
                    return this.YrEnded - this.YrStarted;
                else if (this.YrEnded == 0)
                {
                    now = DateTime.Now;
                    nowYr = now.Year;
                    return nowYr - this.YrStarted;
                }
                else
                    return 0;
            }
        }
    }

    public class Programmer : Person
    {
        public ProgrammingExperience[] ProgExp; // create an array of the ProgrammingExperience class

        public Programmer
            (
                ProgrammingExperience[] Programming_Experience,
                int Emp_ID,
                string FirstName,
                string LastName,
                string Gender
            ) : base
            (
                Emp_ID,
                FirstName,
                LastName,
                Gender
            )
        {
            ProgExp = Programming_Experience;
        }
        
        public ProgrammingExperience[] getProgrammingExperience()
        {
            return ProgExp;
        }
    }


    class Program
    {
        static void Main(string[] args)
        {
            ProgrammingExperience[] myExp = new ProgrammingExperience[5];

            myExp[0] = new ProgrammingExperience(); // need to instantiate each via constructor
            myExp[0].ProgrammingLanguage = "PL/SQL";
            myExp[0].YrStarted = 1985;
            // we will leave end date blank so it should default to now

            myExp[1] = new ProgrammingExperience(); // need to instantiate each via constructor
            myExp[1].ProgrammingLanguage = "C";
            myExp[1].YrStarted = 1985;

            myExp[2] = new ProgrammingExperience(); // need to instantiate each via constructor
            myExp[2].ProgrammingLanguage = "Visual Basic";
            myExp[2].YrStarted = 2000;
            myExp[2].YrEnded = 2010;

            myExp[3] = new ProgrammingExperience(); // need to instantiate each via constructor
            myExp[3].ProgrammingLanguage = "FORTRAN";
            myExp[3].YrStarted = 1980;
            myExp[3].YrEnded = 1985;

            myExp[4] = new ProgrammingExperience(); // need to instantiate each via constructor
            myExp[4].ProgrammingLanguage = "Pascal";
            myExp[4].YrStarted = 1980;
            myExp[4].YrEnded = 1982;

            Programmer p1 = new Programmer(FirstName: "Rick", LastName: "Phillips", Gender:"Male", Emp_ID: 1, Programming_Experience: myExp);
            ProgrammingExperience[] p = p1.getProgrammingExperience();

            Console.WriteLine("{0} {1} is a member of our programming team", p1.getFirstName(), p1.getLastName());

            for (int i=0; i<myExp.Length; i++)
            {
                Console.WriteLine("{0} has been coding {1} for {2} years", p1.getFirstName(), p[i].ProgrammingLanguage, p[i].YearsExperience);
            }
            Console.ReadLine();
        }
    }
}
