﻿using System;

namespace Classes
{
    class Person
    {
        private string fn;  // first name
        private string ln;  // last name
        private string g;   // gender
        private double a;   // age
        private double w;   // weight
        private double h;   // height

        public Person
        (
            string firstName = "Not Specified",
            string lastName = "Not Specified",
            string gender= "Not Specified",
            double age = -1,
            double weight = -1,      // in pounds
            double height = -1      // in inches
        )
        {
            if (firstName.Equals("Not Specified") || lastName.Equals("Not Specified"))
            {
                Console.WriteLine("Throw an error back to the calling routine because required fields are missing");
                Console.WriteLine("Unfortunately, exception handling is in a later chapter so we just use a message now");
                Console.WriteLine("");
            }

            Console.WriteLine("Person object is being created in memory.");
            fn = firstName;
            ln = lastName;
            g = gender;
            a = age;
            w = weight;
            h = height;
        }

        public string getFirstName()
        {
            return fn;
        }

        public string getLastName()
        {
            return ln;
        }

        public string getGender()
        {
            return g;
        }

        public double getAge()
        {
            return a;
        }

        public double getWeight()
        {
            return w;
        }

        public double getHeight()
        {
            return h;
        }

        private bool isAFatty()
        {
            if (w / h > 2.25) // encapsulate (hide) this faulty logic
                return true;
            else
                return false;
        }

        public bool failsBMI()
        {
            return isAFatty();
        }
    }

    class Cube
    {
        private double l, w, h;  // these will be used locally

        public void setLength(double length)
        {
            l = length;
        }

        public void setWidth(double width)
        {
            w = width;
        }

        public void setHeight(double height)
        {
            h = height;
        }

        public double getVolume()
        {
            return l * w * h;
        }
    }

    class Program
    {
        static void Main(string[] args)
        {
            // create two instances of the Cube class named cube1 and cube2
            Cube cube1 = new Cube();
            Cube cube2 = new Cube();

            // set the properties of these Cubes using the appropriate methods
            cube1.setLength(10);
            cube1.setWidth(5.5);
            cube1.setHeight(2);

            cube2.setLength(10);
            cube2.setWidth(5.5);
            cube2.setHeight(4);

            // display the volumes of each Cube with the getVolume method
            Console.WriteLine("Volume of cube1 = {0}", cube1.getVolume());
            Console.WriteLine("Volume of cube2 = {0}", cube2.getVolume());

            Person p1 = new Person("Rick", "Phillips", "Male", 62, 210, 72);
            Person p2 = new Person(weight: 165, height: 75, age: 30, firstName: "David", lastName: "Phillips", gender: "Male");
            Person p3 = new Person(lastName: "Phillips", firstName: "Daniel");
            Person p4 = new Person();

            if (p1.failsBMI())
                Console.WriteLine("{0} loose some weight", p1.getFirstName());
            else
                Console.WriteLine("{0} {1} the gym is really starting to pay off", p1.getFirstName(), p1.getLastName());
            if (p2.failsBMI())
                Console.WriteLine("{0} loose some weight", p2.getFirstName());
            else
                Console.WriteLine("{0} {1} the gym is really starting to pay off", p2.getFirstName(), p2.getLastName());

            p1 = p2;    // this points the p1 instance at p2 (classes are by reference while structures are by value)

            if (p1.failsBMI())
                Console.WriteLine("{0} loose some weight", p1.getFirstName());
            else
                Console.WriteLine("{0} {1} the gym is really starting to pay off", p1.getFirstName(), p1.getLastName());
            if (p2.failsBMI())
                Console.WriteLine("{0} loose some weight", p2.getFirstName());
            else
                Console.WriteLine("{0} {1} the gym is really starting to pay off", p2.getFirstName(), p2.getLastName());

            Console.WriteLine("{0} {1} {2} {3} {4}", p3.getFirstName(), p3.getLastName(), p3.getAge(), p3.getGender(), p3.getHeight());
 
            Console.ReadLine();
        }
    }
}
