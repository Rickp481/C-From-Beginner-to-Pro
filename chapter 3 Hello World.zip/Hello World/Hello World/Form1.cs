﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Hello_World
{
    public partial class Hello_World : Form
    {
        public Hello_World()
        {
            InitializeComponent();
        }

        private void ClickMeButton_Click(object sender, EventArgs e)
        {
            // toggle the visibility of the Hello World label every time the user clicks this button
            if (label1.Visible == true)
            {
                label1.Visible = false;
            }
            else
            {
                label1.Visible = true;
            }
        }

        private void Hello_World_Load(object sender, EventArgs e)
        {
            Label label2 = new Label();
            label2.Text = "Hello 2";
            label2.Location = new Point(135,100);
            label2.Font = new Font(FontFamily.GenericSansSerif, 16, FontStyle.Bold);

            this.Controls.Add(label2);
        }

    }
}
