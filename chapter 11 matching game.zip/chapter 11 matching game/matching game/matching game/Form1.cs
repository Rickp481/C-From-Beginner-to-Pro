﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matching_game
{
    public partial class UserProfile : Form
    {
        public UserProfile()
        {
            InitializeComponent();
        }

        private void UserProfile_Load(object sender, EventArgs e)
        {
            SalutationComboBox.SelectedItem = 0;    // blank
            FirstNameTextBox.Text = null;
            LastNameTextBox.Text = null;
            PrevMinTimeTextBox.Text = "0";
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            // reset simply clears all data entry fields
            SalutationComboBox.SelectedItem = 0;    // blank
            FirstNameTextBox.Text = null;
            LastNameTextBox.Text = null;
            PrevMinTimeTextBox.Text = "0";
        }

        private bool valid_data()
        {
            if (FirstNameTextBox.Text.Length > 0 && LastNameTextBox.Text.Length > 0)
                return true;
            else
            {
                UserErrorMessage.Visible = true;
                return false;
            }

        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            if (valid_data())
            {
                UserErrorMessage.Visible = false;

                // close the current form
                this.Hide();

                // instantiate a new MatchingGame form class and display it concurrently with the UserProfile form
                MatchingGame mg = new MatchingGame(FirstNameTextBox.Text, LastNameTextBox.Text, Convert.ToInt32(PrevMinTimeTextBox.Text));
                mg.ShowDialog();

                this.Close();
            }
            else 
                return;
        }
    }
}
