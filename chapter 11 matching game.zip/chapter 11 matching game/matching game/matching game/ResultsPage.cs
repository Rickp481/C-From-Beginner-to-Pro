﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matching_game
{
    public partial class ResultsPage : Form
    {

        public ResultsPage(string name, int time)
        {
            InitializeComponent();
            if (time == 90)    // the user did not finish the puzzle
            {
                pictureBox1.Load(@"d:\documents\C# From Beginner to Pro\chapter 11 matching game\images\unsuccessful_image.BMP");
                NameTimeLabel.Text = "Sorry " + name + " you did not complete the puzzle in the allotted 90 seconds.";
            }
            else
            {
                pictureBox1.Load(@"d:\documents\C# From Beginner to Pro\chapter 11 matching game\images\success_image.BMP");
                NameTimeLabel.Text = "Congrats " + name + " you completed the puzzle in only " + time.ToString() + " seconds.";
            }
        }

        private void ResultsPage_Load(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Environment.Exit(1);
        }
    }
}
