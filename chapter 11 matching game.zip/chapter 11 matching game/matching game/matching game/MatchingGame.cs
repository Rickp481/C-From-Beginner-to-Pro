﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace matching_game
{
    public partial class MatchingGame : Form
    {
        int user_prev_high_score;

        Random r = new Random();
        List<string> myIcons = new List<string>
            {"a","a","b","b","c","c","d","d","e","e","f","f","g","g","h","h"};
        Label first, second;

        private void AssignIcons()
        {
            foreach (Control c in tableLayoutPanel1.Controls)
            {
                Label l = c as Label;
                int ran = r.Next(myIcons.Count);
                l.Text = myIcons[ran];
                myIcons.RemoveAt(ran);
            }
        }

        private void MatchingGame_Load(object sender, EventArgs e)
        {
            AssignIcons();
            first = null;
            second = null;

            progressBar1.Value = 0;
            TimerLabel.Text = "0";

            foreach (Control c in tableLayoutPanel1.Controls)
            {
                Label l = c as Label;
                l.ForeColor = l.BackColor;    // make the image invisible
            }

            // start the overall duration timer1
            timer1.Start();
        }

        public MatchingGame(string first_name, string last_name, int prev_high)
        {
            InitializeComponent();
            UserName.Text = first_name + " " + last_name;
            user_prev_high_score = prev_high;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            if (progressBar1.Value == 90)
            {
                timer1.Stop();

                // open ResultsPager with the bad news
                this.Hide();

                // instantiate a new ResultsPage form class and display it 
                ResultsPage rp = new ResultsPage(UserName.Text, progressBar1.Value);
                rp.ShowDialog();

                this.Close();

            }

            progressBar1.Value += 1;
            TimerLabel.Text = progressBar1.Value.ToString();
        }


        private void label_click(object sender, EventArgs e)
        {
            Label l = sender as Label;

            if (timer2.Enabled == true || l.ForeColor == Color.Black)
                // user clicked an image while it was visible, ignore the click
                return;

            if (first == null)  // this is the user's first image selection
            {
                first = l;
                first.ForeColor = Color.Black;
                return;
            }

            second = l;
            second.ForeColor = Color.Black;

            CheckForWin();

            if (first.Text == second.Text)  // match found
            {
                first = null;   // leave the images visible
                second = null;
                return;
            } else
            {
                // start timer2
                timer2.Start();
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            timer2.Stop();
            first.ForeColor = first.BackColor;
            second.ForeColor = second.BackColor;

            first = null;
            second = null;
        }

        private void CheckForWin()
        {
            foreach (Control c in tableLayoutPanel1.Controls)
            {
                if (c.ForeColor == c.BackColor) return;
            }

            // the user has won because all images are paired
            timer1.Stop();

            // open results page
            this.Hide();

            // instantiate a new ResultsPage form class and display it 
            ResultsPage rp = new ResultsPage(UserName.Text, progressBar1.Value);
            rp.ShowDialog();

            this.Close();
        }

    }
}
