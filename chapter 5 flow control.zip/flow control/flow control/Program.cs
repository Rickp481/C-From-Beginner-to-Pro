﻿using System;
using System.Collections;
using static System.Console;

namespace flow_control
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 10, b = 20;

            // if command
            if (a == b)
                Console.WriteLine("a = 10 and b = 20, this line is written if a == b");
            else if (a != b)
                Console.WriteLine("a = 10 and b = 20, this line is written if a != b is true");
            else
                Console.WriteLine("this line is written if neither of the above is true");

            if (a > b)
            {
                // the curly brackets are required if this block of code contains more than one command
                Console.WriteLine("a = 10 and b = 20, this line is written if a > b");
            }
            else if ( a >= b)
            {
                Console.WriteLine("a = 10, b = 20 this line is written if a >= b");
            }
            else 
            {
                Console.WriteLine("a = 10 and b = 20, this line is written if neither of the above is true");
            }         

            switch (a + b)
            {
                case -5:
                    Console.WriteLine("a = 10, b = 20 so a+b=-5");
                    break;
                case 0:
                    Console.WriteLine("a = 10, b = 20 so a+b=0");
                    break;
                case 20:
                    Console.WriteLine("a = 10, b = 20 so a+b=20");
                    break;
                default:
                    Console.WriteLine("none of the above was true so we executed the default block");
                    break;
            }

            Random r = new Random();
            int newRandom, counter = 0;

            while (counter < 5)
            {
                newRandom = r.Next(0,100);  // random number between 0 and 99
                WriteLine("Random number " + counter + " was " + newRandom);
                counter += 1; // the +- operator is equivalent to counter = counter + 1
            }
            
            int[] values = new int[10]; // create an array of integers with 10 elements

            while (counter < 10)
            {
                newRandom = r.Next(0, 100);
                values[counter] = newRandom;
                counter += 1;
            }

            for (int lcv=0; lcv<10; lcv++)
            {
                WriteLine("Random number " + lcv + " was " + values[lcv]);
            }

            WriteLine();

            for (int lcv = 0; lcv < 10; lcv+=10)
            {
                WriteLine("Random number " + lcv + " was " + values[lcv]);
            }
            
            ArrayList names = new ArrayList();
            names.Add("Rick");
            names.Add("Mary");
            names.Add("Daniel");
            names.Add("David");

            foreach (string name in names)
            {
                WriteLine(name);
            }

            ReadLine();

        }

    }
}
