﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parent_child_with_stored_procedures
{
    public partial class Form1 : Form
    {
        private DataTable tblCustomers, tblOrders, tblLineItems, tblProducts;
        private DataTable tblCustomersDels, tblOrdersDels, tblLineItemsDels;
        private DataSet tblDataSet;
        private SqlCommand myCommand;
        private SqlDataAdapter myDA;
        private ComboBox combo;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tblCustomers = new DataTable("tblCustomers");
            tblOrders = new DataTable("tblOrders");
            tblLineItems = new DataTable("tblLineItems");
            tblProducts = new DataTable("tblProducts");
            tblCustomersDels = new DataTable("tblCustomersDels");
            tblOrdersDels = new DataTable("tblOrdersDels");
            tblLineItemsDels = new DataTable("tblLineItemsDels");

            tblCustomersDels.Columns.Add("customer_id");
            tblOrdersDels.Columns.Add("customer_id");
            tblOrdersDels.Columns.Add("order_id");
            tblLineItemsDels.Columns.Add("order_id");
            tblLineItemsDels.Columns.Add("lineitem");

            SqlConnection myCon = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");
            myCon.Open();
            
            myCommand = new SqlCommand("readCustomers",myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("cust_id",-1);    // get all customer records
            myDA = new SqlDataAdapter(myCommand);
            myDA.Fill(tblCustomers);

            myCommand = new SqlCommand("readOrders", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("cust_id", -1);   
            myCommand.Parameters.AddWithValue("ord_id", -1);    
            myDA = new SqlDataAdapter(myCommand);
            myDA.Fill(tblOrders);

            myCommand = new SqlCommand("readLineItems", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("ord_id", -1);
            myDA = new SqlDataAdapter(myCommand);
            myDA.Fill(tblLineItems);

            myCommand = new SqlCommand("readProducts", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;
            myCommand.Parameters.AddWithValue("prod_id", -1);
            myDA = new SqlDataAdapter(myCommand);
            myDA.Fill(tblProducts);

            tblDataSet = new DataSet();
            tblDataSet.Tables.Add(tblCustomers);
            tblDataSet.Tables.Add(tblOrders);
            tblDataSet.Tables.Add(tblLineItems);

            tblDataSet.Relations.Add("Cust_Ord_Relation",tblCustomers.Columns["customer_id"], tblOrders.Columns["customer_id"]);
            tblDataSet.Relations.Add("Ord_Line_Relation", tblOrders.Columns["order_id"], tblLineItems.Columns["order_id"]);

            BindingSource bsCust = new BindingSource();
            bsCust.DataSource = tblDataSet;
            bsCust.DataMember = "tblCustomers";
            BindingSource bsOrd = new BindingSource();
            bsOrd.DataSource = bsCust;
            bsOrd.DataMember = "Cust_Ord_Relation";
            BindingSource bsLine = new BindingSource();
            bsLine.DataSource = bsOrd;
            bsLine.DataMember = "Ord_Line_Relation";

            customersGridView.DataSource = bsCust;
            ordersGridView.DataSource = bsOrd;
            lineitemsGridView.DataSource = bsLine;

            lineitemsGridView.Columns.Add("Product_Desc","Product");

            ArrayList StringList = new ArrayList();
            foreach(DataRow row in tblProducts.Rows)
            {
                StringList.Add(row["product_desc"].ToString());
            }
            for (int i=0; i<lineitemsGridView.Rows.Count-1; i++)
            {
                var myCell = new DataGridViewComboBoxCell();
                myCell.DataSource = StringList;
                lineitemsGridView.Rows[i].Cells[6] = myCell;
            }
            for (int i=0; i<lineitemsGridView.Rows.Count-1; i++)
            {
                for (int j=0; j<StringList.Count;j++)
                {
                    if (StringList[j].ToString() == lineitemsGridView.Rows[i].Cells[5].Value.ToString())
                        lineitemsGridView.Rows[i].Cells[6].Value = StringList[j];
                }
            }

            myCon.Close();
        }

        private void customersGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (ordersGridView.Rows.Count == 1) // remember an empty grid has a row for adding
                tblCustomersDels.Rows.Add(customersGridView.CurrentRow.Cells["customer_id"].Value);
            else
            {
                MessageBox.Show("You may not delete a customer with orders. Please remove orders first");
                e.Cancel = true;
            }
        }
        private void ordersGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (lineitemsGridView.Rows.Count == 1)
                tblOrdersDels.Rows.Add(ordersGridView.CurrentRow.Cells["customer_id"].Value,
                                        ordersGridView.CurrentRow.Cells["order_id"].Value);
            else
            {
                MessageBox.Show("You may not delete an order with lineitems. Please delete lineitems first.");
                e.Cancel = true;
            }
        }
        private void lineitemsGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            tblLineItemsDels.Rows.Add(lineitemsGridView.CurrentRow.Cells["order_id"].Value,
                                        lineitemsGridView.CurrentRow.Cells["lineitem"].Value);  // this is failing with too many columns
        }


        private void customersGridView_SelectionChanged(object sender, EventArgs e)
        {
            SelectionChanged();
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            SqlConnection myCon = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");
            myCon.Open();

            myCommand = new SqlCommand("updateCustomer", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;

            foreach (DataRow myRow in tblCustomers.Rows)
            {
                // we will do inserts first
                if (myRow.RowState == DataRowState.Added)
                {
                    myCommand.Parameters.AddWithValue("@customer_id", 0); // new customer_id will come back in the @new_id parm
                    myCommand.Parameters.AddWithValue("@first_name", myRow["first_name"]);
                    myCommand.Parameters.AddWithValue("@last_name", myRow["last_name"]);
                    myCommand.Parameters.AddWithValue("@telephone", myRow["telephone"]);
                    myCommand.Parameters.AddWithValue("@email", myRow["email"]);
                    myCommand.Parameters.AddWithValue("@update_type", 1);    // insert
                    myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                    myCommand.ExecuteNonQuery();

                    if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")    // something went wrong
                        MessageBox.Show("Customer " + myRow["first_name"] + " " + myRow["last_name"] +
                                         " was not added to the database due to an unexpected error. ");
                    else
                        myRow["customer_id"] = (int)myCommand.Parameters["@new_id"].Value;

                    myCommand.Parameters.Clear();
                }
                else if (myRow.RowState == DataRowState.Modified)
                {
                    myCommand.Parameters.AddWithValue("@customer_id", myRow["customer_id"]);
                    myCommand.Parameters.AddWithValue("@first_name", myRow["first_name"]);
                    myCommand.Parameters.AddWithValue("@last_name", myRow["last_name"]);
                    myCommand.Parameters.AddWithValue("@telephone", myRow["telephone"]);
                    myCommand.Parameters.AddWithValue("@email", myRow["email"]);
                    myCommand.Parameters.AddWithValue("@update_type", 2);    // update
                    myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                    myCommand.ExecuteNonQuery();

                    if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")    // something went wrong
                        MessageBox.Show("Customer " + myRow["first_name"] + " " + myRow["last_name"] +
                                         " was not updated in the database due to an unexpected error. ");

                    myCommand.Parameters.Clear();
                }
            }

            // ok, next we work on the orders
            myCommand = new SqlCommand("updateOrders", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;

            foreach (DataRow myRow in tblOrders.Rows)
            {
                if (myRow.RowState == DataRowState.Added)
                {
                    myCommand.Parameters.AddWithValue("@customer_id", myRow["customer_id"]);
                    myCommand.Parameters.AddWithValue("@order_id", -1);
                    myCommand.Parameters.AddWithValue("@update_type", 1);
                    myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;
                    myCommand.ExecuteNonQuery();

                    if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")
                        MessageBox.Show("An order for customer " + myRow["customer_id"] + " was not inserted due to an unexpected error.");
                    else
                        myRow["order_id"] = (int)myCommand.Parameters["@new_id"].Value;
                }
                myCommand.Parameters.Clear();
            }
            // NOTE: order updates don't make any sense as all the columns are system generated

            // now the lineitems
            myCommand = new SqlCommand("updateLineItems", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;

            foreach (DataRow myRow in tblLineItems.Rows)
            {
                if (myRow.RowState == DataRowState.Added)
                {
                    myCommand.Parameters.AddWithValue("@order_id", myRow["order_id"]);
                    myCommand.Parameters.AddWithValue("@lineitem", -1);
                    myCommand.Parameters.AddWithValue("@product_desc", myRow["product_desc"]);
                    myCommand.Parameters.AddWithValue("@order_quantity", myRow["order_quantity"]);
                    myCommand.Parameters.AddWithValue("@extended_price", myRow["extended_price"]);
                    myCommand.Parameters.AddWithValue("@update_type", 1);
                    myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                    myCommand.ExecuteNonQuery();

                    if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")
                        MessageBox.Show("Lineitem " + myRow["order_id"].ToString() + " " + myRow["lineitem"].ToString() +
                                        " was not inserted due to an unexpected error.");
                    else
                        myRow["lineitem"] = (int)myCommand.Parameters["@new_id"].Value;

                    myCommand.Parameters.Clear();
                }

                if (myRow.RowState == DataRowState.Modified)
                {
                    myCommand.Parameters.AddWithValue("@order_id", myRow["order_id"]);
                    myCommand.Parameters.AddWithValue("@lineitem", myRow["lineitem"]);
                    myCommand.Parameters.AddWithValue("@product_desc", myRow["product_desc"]);
                    myCommand.Parameters.AddWithValue("@order_quantity", myRow["order_quantity"]);
                    myCommand.Parameters.AddWithValue("@extended_price", myRow["extended_price"]);
                    myCommand.Parameters.AddWithValue("@update_type", 2);
                    myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                    myCommand.ExecuteNonQuery();

                    if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")
                        MessageBox.Show("Lineitem " + myRow["order_id"].ToString() + " " + myRow["lineitem"].ToString() +
                                        " was not updated due to an unexpected error.");
                    myCommand.Parameters.Clear();
                }
            }

            // now the deletes, remember work from the leaf nodes to the RI root
            myCommand = new SqlCommand("updateLineItems", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;

            foreach (DataRow myRow in tblLineItemsDels.Rows)
            {
                myCommand.Parameters.AddWithValue("@order_id", myRow["order_id"]);
                myCommand.Parameters.AddWithValue("@lineitem", myRow["lineitem"]);
                myCommand.Parameters.AddWithValue("@product_desc", "");
                myCommand.Parameters.AddWithValue("@order_quantity", "");
                myCommand.Parameters.AddWithValue("@extended_price", "");
                myCommand.Parameters.AddWithValue("@update_type", 3);
                myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                myCommand.ExecuteNonQuery();

                if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")
                    MessageBox.Show("Lineitem " + myRow["order_id"].ToString() + " " + myRow["lineitem"].ToString() +
                                    " was not deleted due to an unexpected error.");

                myCommand.Parameters.Clear();

            }

            myCommand = new SqlCommand("updateOrders", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;

            foreach (DataRow myRow in tblOrdersDels.Rows)
            {
                myCommand.Parameters.AddWithValue("@customer_id", myRow["customer_id"]);
                myCommand.Parameters.AddWithValue("@order_id", myRow["order_id"]);
                myCommand.Parameters.AddWithValue("@update_type", 3);
                myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                myCommand.ExecuteNonQuery();

                if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")
                    MessageBox.Show("An order for customer " + myRow["customer_id"] + " was not deleted due to an unexpected error.");

                myCommand.Parameters.Clear();
            }

            myCommand = new SqlCommand("updateCustomers", myCon);
            myCommand.CommandType = CommandType.StoredProcedure;

            foreach (DataRow myRow in tblCustomersDels.Rows)
            {
                myCommand.Parameters.AddWithValue("@customer_id", myRow["customer_id"]);
                myCommand.Parameters.AddWithValue("@first_name", "");
                myCommand.Parameters.AddWithValue("@last_name", "");
                myCommand.Parameters.AddWithValue("@telephone", "");
                myCommand.Parameters.AddWithValue("@email", "");
                myCommand.Parameters.AddWithValue("@update_type", 3);  
                myCommand.Parameters.Add("@new_id", SqlDbType.Int).Direction = ParameterDirection.Output;

                myCommand.ExecuteNonQuery();

                if (myCommand.Parameters["@new_id"].Value.ToString() == "-1")    // something went wrong
                    MessageBox.Show("Customer " + myRow["first_name"] + " " + myRow["last_name"] +
                                     " was not deleted from the database due to an unexpected error. ");

                myCommand.Parameters.Clear();
            }

            MessageBox.Show("Database updates were completed successfully");
        }

        private void ordersGridView_SelectionChanged(object sender, EventArgs e)
        {
            SelectionChanged();
        }

        private void SelectionChanged()
        {
            ArrayList StringList = new ArrayList(); // build data source
            foreach(DataRow row in tblProducts.Rows)
                StringList.Add(row["product_desc"].ToString());
            for (int i=0; i < lineitemsGridView.Rows.Count-1; i++) // add ComboBox with data source
            {
                var myCell = new DataGridViewComboBoxCell();
                myCell.DataSource = StringList;
                lineitemsGridView.Rows[i].Cells[6] = myCell;
            }
            for (int i=0; i<lineitemsGridView.Rows.Count-1; i++) // set selected
            {
                for (int j=0; j<StringList.Count;j++)
                {
                    if (StringList[j].ToString() == lineitemsGridView.Rows[i].Cells[5].Value)
                        lineitemsGridView.Rows[i].Cells[6].Value = StringList[j];
                }
            }
        }

        private void lineitemsGridView_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            SqlConnection myCon3 = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");
            SqlDataAdapter myDA4 = new SqlDataAdapter("select product_id, product_desc from products order by product_desc", myCon3);
            tblProducts = new DataTable("tblProducts");
            myDA4.Fill(tblProducts);

            ArrayList StringList = new ArrayList();
            
            foreach (DataRow row in tblProducts.Rows)
                StringList.Add(row["product_desc"].ToString());
            
            var myCell = new DataGridViewComboBoxCell();
            myCell.DataSource = StringList;

            int myRowIndex = lineitemsGridView.Rows.Count - 2;  // -2 because it is a new row
            lineitemsGridView.Rows[myRowIndex].Cells[6] = myCell;
        }

        private void lineitemsGridView_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            combo = e.Control as ComboBox;
            if (combo != null)
            {
                combo.SelectedIndexChanged -= new EventHandler(combo_SelectedIndexChanged);
                combo.SelectedIndexChanged += combo_SelectedIndexChanged;
            }
        }

        private void combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = (sender as ComboBox).SelectedItem.ToString();
            lineitemsGridView.CurrentRow.Cells["product_desc"].Value = selected;
        }
    }
}
