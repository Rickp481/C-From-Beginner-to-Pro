﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multi_select_wizard
{
    public partial class SelectedItems : Form
    {
        public SelectedItems(ListBox.ObjectCollection myItems)
        {
            InitializeComponent();

            for (int i=0; i<myItems.Count; i++)
            {
                Label l = new Label();
                l.Text = myItems[i].ToString();
                l.Location = new Point(100, i * 25 + 40);
                l.Font = new Font("Times New Roman", 12);

                this.Controls.Add(l);
            }
        }

        private void SelectedItems_Load(object sender, EventArgs e)
        {

        }
    }
}
