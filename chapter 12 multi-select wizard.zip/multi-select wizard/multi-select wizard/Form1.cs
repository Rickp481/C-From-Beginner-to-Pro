﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace multi_select_wizard
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            setup_listboxes();

            MoveRightButton.Text = "\u2192";    // unicode for right arrow
            MoveLeftButton.Text = "\u2190";
        }

        public void setup_listboxes()
        {
            LeftListBox.Items.Clear();
            RightListBox.Items.Clear();

            for (int i=0; i<10; i++)
            {
                LeftListBox.Items.Insert(i, "Item number " + i);
            }

            LeftListBox.Sorted = true;
            RightListBox.Sorted = true;
        }

        private void AllLefftButton_Click(object sender, EventArgs e)
        {
            for (int i=0; i < LeftListBox.Items.Count; i++) 
            {
                LeftListBox.SetSelected(i, true);
            }
        }

        private void AllRightButton_Click(object sender, EventArgs e)
        {
            for (int i=0; i < RightListBox.Items.Count; i++)
            {
                RightListBox.SetSelected(i, true);
            }
        }

        private void MoveRightButton_Click(object sender, EventArgs e)
        {
            // if left side item is selected move it to the right side
            for (int i=0; i < LeftListBox.Items.Count; i++)
            {
                if (LeftListBox.GetSelected(i) == true) // it is selected
                {
                    RightListBox.Items.Add(LeftListBox.Items[i]);   // move it
                }
            }

            // now reverse the loop for the removes
            for (int i = LeftListBox.Items.Count-1; i>=0; i--)
            {
                if (LeftListBox.GetSelected(i) == true) LeftListBox.Items.RemoveAt(i);
            }
        }

        private void MoveLeftButton_Click(object sender, EventArgs e)
        {
            for (int i=0; i < RightListBox.Items.Count; i++)
            {
                if (RightListBox.GetSelected(i) == true)
                {
                    LeftListBox.Items.Add(RightListBox.Items[i]);
                }
            }

            for (int i = RightListBox.Items.Count-1; i >= 0; i--)
            {
                if (RightListBox.GetSelected(i) == true) RightListBox.Items.RemoveAt(i);
            }
        }

        private void ResetButton_Click(object sender, EventArgs e)
        {
            setup_listboxes();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            // we are going to just pass these items down stream to the SelectedItems page
            this.Hide();

            SelectedItems si = new SelectedItems(RightListBox.Items); 
            si.ShowDialog();

            this.Close();
        }
    }
}
