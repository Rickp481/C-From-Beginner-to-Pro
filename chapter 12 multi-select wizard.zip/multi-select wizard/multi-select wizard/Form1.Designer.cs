﻿namespace multi_select_wizard
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.LeftListBox = new System.Windows.Forms.ListBox();
            this.RightListBox = new System.Windows.Forms.ListBox();
            this.AllLefftButton = new System.Windows.Forms.Button();
            this.AllRightButton = new System.Windows.Forms.Button();
            this.MoveLeftButton = new System.Windows.Forms.Button();
            this.MoveRightButton = new System.Windows.Forms.Button();
            this.ResetButton = new System.Windows.Forms.Button();
            this.SubmitButton = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // LeftListBox
            // 
            this.LeftListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LeftListBox.FormattingEnabled = true;
            this.LeftListBox.ItemHeight = 25;
            this.LeftListBox.Location = new System.Drawing.Point(50, 100);
            this.LeftListBox.Name = "LeftListBox";
            this.LeftListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.LeftListBox.Size = new System.Drawing.Size(400, 354);
            this.LeftListBox.Sorted = true;
            this.LeftListBox.TabIndex = 0;
            // 
            // RightListBox
            // 
            this.RightListBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RightListBox.FormattingEnabled = true;
            this.RightListBox.ItemHeight = 25;
            this.RightListBox.Location = new System.Drawing.Point(700, 100);
            this.RightListBox.Name = "RightListBox";
            this.RightListBox.SelectionMode = System.Windows.Forms.SelectionMode.MultiExtended;
            this.RightListBox.Size = new System.Drawing.Size(400, 354);
            this.RightListBox.Sorted = true;
            this.RightListBox.TabIndex = 1;
            // 
            // AllLefftButton
            // 
            this.AllLefftButton.Location = new System.Drawing.Point(460, 100);
            this.AllLefftButton.Name = "AllLefftButton";
            this.AllLefftButton.Size = new System.Drawing.Size(50, 20);
            this.AllLefftButton.TabIndex = 2;
            this.AllLefftButton.Text = "All";
            this.AllLefftButton.UseVisualStyleBackColor = true;
            this.AllLefftButton.Click += new System.EventHandler(this.AllLefftButton_Click);
            // 
            // AllRightButton
            // 
            this.AllRightButton.Location = new System.Drawing.Point(640, 430);
            this.AllRightButton.Name = "AllRightButton";
            this.AllRightButton.Size = new System.Drawing.Size(50, 20);
            this.AllRightButton.TabIndex = 3;
            this.AllRightButton.Text = "All";
            this.AllRightButton.UseVisualStyleBackColor = true;
            this.AllRightButton.Click += new System.EventHandler(this.AllRightButton_Click);
            // 
            // MoveLeftButton
            // 
            this.MoveLeftButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoveLeftButton.Location = new System.Drawing.Point(530, 290);
            this.MoveLeftButton.Name = "MoveLeftButton";
            this.MoveLeftButton.Size = new System.Drawing.Size(100, 40);
            this.MoveLeftButton.TabIndex = 4;
            this.MoveLeftButton.UseVisualStyleBackColor = true;
            this.MoveLeftButton.Click += new System.EventHandler(this.MoveLeftButton_Click);
            // 
            // MoveRightButton
            // 
            this.MoveRightButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MoveRightButton.Location = new System.Drawing.Point(530, 230);
            this.MoveRightButton.Name = "MoveRightButton";
            this.MoveRightButton.Size = new System.Drawing.Size(100, 40);
            this.MoveRightButton.TabIndex = 5;
            this.MoveRightButton.UseVisualStyleBackColor = true;
            this.MoveRightButton.Click += new System.EventHandler(this.MoveRightButton_Click);
            // 
            // ResetButton
            // 
            this.ResetButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ResetButton.Location = new System.Drawing.Point(170, 500);
            this.ResetButton.Name = "ResetButton";
            this.ResetButton.Size = new System.Drawing.Size(100, 40);
            this.ResetButton.TabIndex = 6;
            this.ResetButton.Text = "Reset";
            this.ResetButton.UseVisualStyleBackColor = true;
            this.ResetButton.Click += new System.EventHandler(this.ResetButton_Click);
            // 
            // SubmitButton
            // 
            this.SubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SubmitButton.Location = new System.Drawing.Point(840, 500);
            this.SubmitButton.Name = "SubmitButton";
            this.SubmitButton.Size = new System.Drawing.Size(100, 40);
            this.SubmitButton.TabIndex = 7;
            this.SubmitButton.Text = "Submit";
            this.SubmitButton.UseVisualStyleBackColor = true;
            this.SubmitButton.Click += new System.EventHandler(this.SubmitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 561);
            this.Controls.Add(this.SubmitButton);
            this.Controls.Add(this.ResetButton);
            this.Controls.Add(this.MoveRightButton);
            this.Controls.Add(this.MoveLeftButton);
            this.Controls.Add(this.AllRightButton);
            this.Controls.Add(this.AllLefftButton);
            this.Controls.Add(this.RightListBox);
            this.Controls.Add(this.LeftListBox);
            this.Name = "Form1";
            this.Text = "Multi-Select Wizard";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox LeftListBox;
        private System.Windows.Forms.ListBox RightListBox;
        private System.Windows.Forms.Button AllLefftButton;
        private System.Windows.Forms.Button AllRightButton;
        private System.Windows.Forms.Button MoveLeftButton;
        private System.Windows.Forms.Button MoveRightButton;
        private System.Windows.Forms.Button ResetButton;
        private System.Windows.Forms.Button SubmitButton;
    }
}

