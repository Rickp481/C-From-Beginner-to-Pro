﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace Database_Connection
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Text = "Database Connection";
            this.Size = new Size(900, 750);

            // add a DataGrid object
            DataGrid dg = new DataGrid();
            dg.Size = new Size(800, 650);
            dg.Location = new Point(50, 50);
            dg.BorderStyle = BorderStyle.Fixed3D;
            dg.Visible = true;
            this.Controls.Add(dg);

            // now set up a connection to the local instance of SQL Server
            SqlConnection myCon = new SqlConnection(@"Data Source=DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog=Orders_DB; Integrated Security = true;");

            // the SqlDataAdapter class allows us to stream data across our connection
            SqlDataAdapter myDA = new SqlDataAdapter("select product_id, product_desc from products order by product_id desc", myCon);

            // the DataTable class actus just like a relational database table in local memory
            DataTable myDT = new DataTable();

            // call the SqlDataAdapter.Fill method to populate our DataTable
            myDA.Fill(myDT);

            // point the DataSource property of our DataGrid to our local DataTable
            dg.DataSource = myDT;

        }
    }
}
