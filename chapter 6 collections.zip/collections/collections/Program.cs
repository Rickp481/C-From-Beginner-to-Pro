﻿using System;
using System.Collections;

namespace collections
{
    class Program
    {
        struct Person
        {
            private int i, a;
            private string f, l, g;

            public void getValues(int ID, string fname, string lname, int age, string gender)
            {
                i = ID;
                f = fname;
                l = lname;
                a = age;
                g = gender;
            }

            public void displayValues()
            {
                Console.WriteLine("{0} {1} is ID = {2}, age = {3} and gender = {4}", f, l, i, a, g);
            }
        }

        enum Colors {Red, Orange, Yellow, Green, Blue, Indigo, Violet };
        enum Months {January, February, March, April, May, June, July, August, September, October, November, December };

        static void Main(string[] args)
        {
            
            // declare and instantiate an array of type integer
            int[] values = new int[] { 100, 200, 300, 400, 500 };
            int[,] towdim = new int[,] { { 1,2,3}, {9,8,7} };
            int[,,] threedim = new int[,,]
            {
                {
                    {1,2,3},
                    {4,5,6},
                    {7,8,9}
                },
                {
                    {11,22,33 },
                    {44,55,66 },
                    {77,88,99 }
                },
            };

            for (int i=0; i<values.Length; i++)
            {
                Console.WriteLine("array values index " + i + " = " + values[i]);
            }
            
            Console.WriteLine("Dimension 0 of twodim has {0} elements", towdim.GetLength(0));
            Console.WriteLine("Dimension 1 of twodim has {0} elements", towdim.GetLength(1));

            for (int i=0; i<towdim.GetLength(0); i++)
            {
                for (int j = 0; j < towdim.GetLength(1); j++)
                {
                    Console.WriteLine("twpdim[{0},{1}]={2} ",i,j,towdim[i,j]);
                }
            }

            Console.WriteLine("Dimension 0 of threedim has {0} elements", threedim.GetLength(0));
            Console.WriteLine("Dimension 1 of threedim has {0} elements", threedim.GetLength(1));
            Console.WriteLine("Dimension 2 of threedim has {0} elements", threedim.GetLength(2));

            for (int i = 0; i < threedim.GetLength(0); i++)
            {
                for (int j = 0; j < threedim.GetLength(1); j++)
                {
                    for (int k = 0; k < threedim.GetLength(2); k++)
                    {
                        Console.WriteLine("threedim[{0},{1},{2}]={3} ", i, j, k, threedim[i, j, k]);
                    }
                }
            }

            ArrayList myStuff = new ArrayList(); // please note that the ArrayList class requires the System.Collections namespace
            for (int i=0; i<10; i++)
            {
                myStuff.Add(i % 5);
                Console.WriteLine("value of myStuff[{0}] = {1}", i, myStuff[i]);
            }

            myStuff.Sort(); // sort the stored values and reindexes accordingly
            for (int i = 0; i < 10; i++)
            {
                Console.WriteLine("value of myStuff[{0}] = {1}", i, myStuff[i]);
            }
            
            Person me = new Person();   // instantiate two instances of Person struct
            Person myWife = new Person();

            me.getValues(0,"Rick","Phillips",62,"Male");
            myWife.getValues(1, "Mary", "Phillips", 62, "Female");
            me.displayValues();
            myWife.displayValues();

            int myEyes, myBday;

            myEyes = (int)Colors.Blue;
            myBday = (int)Months.February;

            Console.WriteLine("Rick's eyes are {0} which translates to {1}", myEyes, Colors.Blue);
            Console.WriteLine("Rick's birthday is in {0} which translates to {1}", myBday, Months.February);

            Console.ReadLine();
        }
    }
}
