﻿namespace parent_child
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.customersGridView = new System.Windows.Forms.DataGridView();
            this.ordersGridView = new System.Windows.Forms.DataGridView();
            this.lineitemsGridView = new System.Windows.Forms.DataGridView();
            this.submitButton = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.customersGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersGridView)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.lineitemsGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // customersGridView
            // 
            this.customersGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.customersGridView.Location = new System.Drawing.Point(25, 25);
            this.customersGridView.Name = "customersGridView";
            this.customersGridView.Size = new System.Drawing.Size(550, 250);
            this.customersGridView.TabIndex = 0;
            this.customersGridView.SelectionChanged += new System.EventHandler(this.customersGridView_SelectionChanged);
            this.customersGridView.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.customersGridView_UserAddedRow);
            this.customersGridView.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.customersGridView_UserDeletingRow);
            // 
            // ordersGridView
            // 
            this.ordersGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ordersGridView.Location = new System.Drawing.Point(650, 25);
            this.ordersGridView.Name = "ordersGridView";
            this.ordersGridView.Size = new System.Drawing.Size(500, 250);
            this.ordersGridView.TabIndex = 1;
            this.ordersGridView.SelectionChanged += new System.EventHandler(this.ordersGridView_SelectionChanged);
            this.ordersGridView.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.ordersGridView_UserAddedRow);
            this.ordersGridView.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.ordersGridView_UserDeletingRow);
            // 
            // lineitemsGridView
            // 
            this.lineitemsGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.lineitemsGridView.Location = new System.Drawing.Point(25, 300);
            this.lineitemsGridView.Name = "lineitemsGridView";
            this.lineitemsGridView.Size = new System.Drawing.Size(1125, 350);
            this.lineitemsGridView.TabIndex = 2;
            this.lineitemsGridView.EditingControlShowing += new System.Windows.Forms.DataGridViewEditingControlShowingEventHandler(this.lineitemsGridView_EditingControlShowing);
            this.lineitemsGridView.UserAddedRow += new System.Windows.Forms.DataGridViewRowEventHandler(this.lineitemsGridView_UserAddedRow);
            this.lineitemsGridView.UserDeletingRow += new System.Windows.Forms.DataGridViewRowCancelEventHandler(this.lineitemsGridView_UserDeletingRow);
            // 
            // submitButton
            // 
            this.submitButton.BackColor = System.Drawing.Color.Red;
            this.submitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.submitButton.Location = new System.Drawing.Point(450, 675);
            this.submitButton.Name = "submitButton";
            this.submitButton.Size = new System.Drawing.Size(250, 50);
            this.submitButton.TabIndex = 3;
            this.submitButton.Text = "Submit";
            this.submitButton.UseVisualStyleBackColor = false;
            this.submitButton.Click += new System.EventHandler(this.submitButton_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1184, 761);
            this.Controls.Add(this.submitButton);
            this.Controls.Add(this.lineitemsGridView);
            this.Controls.Add(this.ordersGridView);
            this.Controls.Add(this.customersGridView);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultBounds;
            this.Text = "Customer Service";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.customersGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.ordersGridView)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.lineitemsGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView customersGridView;
        private System.Windows.Forms.DataGridView ordersGridView;
        private System.Windows.Forms.DataGridView lineitemsGridView;
        private System.Windows.Forms.Button submitButton;
    }
}

