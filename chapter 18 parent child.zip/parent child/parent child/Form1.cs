﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace parent_child
{
    public partial class Form1 : Form
    {
        private DataTable tblCustomers, tblOrders, tblLineItems, tblProducts;
        private DataSet tblDataSet;
        private ComboBox combo;
        private DataTable tblCustomersDels, tblOrdersDels, tblLineItemsDels;
        private SqlCommand myCommand;
        private bool user_added_customer_row = false, user_added_order_row = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            tblCustomersDels = new DataTable("tblCustomersDels");
            tblCustomersDels.Columns.Add("customer_id");
            tblOrdersDels = new DataTable("tblOrdersDels");
            tblOrdersDels.Columns.Add("customer_id");
            tblOrdersDels.Columns.Add("order_id");
            tblLineItemsDels = new DataTable("tblLineItemsDels");
            tblLineItemsDels.Columns.Add("order_id");
            tblLineItemsDels.Columns.Add("lineitem");

            SqlConnection myCon = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");
            SqlDataAdapter myDA1 = new SqlDataAdapter("select customer_id, first_name, last_name, email, telephone from customers order by customer_id", myCon);
            tblCustomers = new DataTable("tblCustomers");
            myDA1.Fill(tblCustomers);

            SqlDataAdapter myDA2 = new SqlDataAdapter("select customer_id, order_id, order_date from orders order by order_id", myCon);
            tblOrders = new DataTable("tblOrders");
            myDA2.Fill(tblOrders);

            SqlDataAdapter myDA3 = new SqlDataAdapter("select a.order_id, a.lineitem, a.order_quantity, a.product_id, b.product_desc, a.extended_price " +
                                                      "from   order_lineitems a, products b " +
                                                      "where  a.product_id = b.product_id " +
                                                      "order by order_id, lineitem", myCon);
            tblLineItems = new DataTable("tblLineItems");
            myDA3.Fill(tblLineItems);

            tblDataSet = new DataSet();

            // load the Tables collection
            tblDataSet.Tables.Add(tblCustomers);
            tblDataSet.Tables.Add(tblOrders);
            tblDataSet.Tables.Add(tblLineItems);

            // load the Relations collection
            tblDataSet.Relations.Add("Cust_Ord_Relation", tblCustomers.Columns["customer_id"], tblOrders.Columns["customer_id"]);
            tblDataSet.Relations.Add("Ord_Line_Relation", tblOrders.Columns["order_id"], tblLineItems.Columns["order_id"]);

            // create bindingsources to chain down our relationships
            BindingSource bsCust = new BindingSource();
            bsCust.DataSource = tblDataSet; // set the source equal to the entire dataset
            bsCust.DataMember = "tblCustomers"; // top parent

            BindingSource bsOrd = new BindingSource();
            bsOrd.DataSource = bsCust;  // parent
            bsOrd.DataMember = "Cust_Ord_Relation"; // follow down the relationship to the child

            BindingSource bsLine = new BindingSource();
            bsLine.DataSource = bsOrd;  // parent
            bsLine.DataMember = "Ord_Line_Relation"; // follow dow the relationship to the child

            // now set the datasource of each grid to the corresponding bindingsource
            customersGridView.DataSource = bsCust;
            ordersGridView.DataSource = bsOrd;
            lineitemsGridView.DataSource = bsLine;

            // add a column to the lineitems grid
            lineitemsGridView.Columns.Add("Product_Desc", "Product");

            SelectionChanged();

            myCon.Close();

            customersGridView.AllowUserToAddRows = true;
            user_added_customer_row = false;
            ordersGridView.AllowUserToAddRows = true;
            user_added_order_row = false;
        }

        private void customersGridView_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (user_added_customer_row == false)
            {
                customersGridView.AllowUserToAddRows = false;
                user_added_customer_row = true;
            }
        }

        private void ordersGridView_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            if (user_added_order_row == false)
            {
                ordersGridView.AllowUserToAddRows = false;
                user_added_order_row = true;
            }
        }

        private void lineitemsGridView_UserAddedRow(object sender, DataGridViewRowEventArgs e)
        {
            SqlConnection myCon3 = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");

            // now let's replace that product_id field with a dropdown
            SqlDataAdapter myDA4 = new SqlDataAdapter("select product_id, product_desc from products order by product_desc", myCon3);
            tblProducts = new DataTable("tblProducts");
            myDA4.Fill(tblProducts);

            // dropdown wants an ArrayList as it's datasource
            ArrayList StringList = new ArrayList();

            // populate that arraylist from tblproducts
            foreach (DataRow row in tblProducts.Rows)
            {
                StringList.Add(row["product_desc"].ToString());
            }

            var myCell = new DataGridViewComboBoxCell();
            myCell.DataSource = StringList;

            // remember we have already added a line so we are really at count-2
            int myRowIndex = lineitemsGridView.Rows.Count - 2;
            lineitemsGridView.Rows[myRowIndex].Cells[6] = myCell;

            myCon3.Close();
        }

        private void customersGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (ordersGridView.Rows.Count == 1) // 1 because child grid will contain 1 row for insert
                tblCustomersDels.Rows.Add(customersGridView.CurrentRow.Cells["customer_id"].Value);
            else
            {
                MessageBox.Show("You may not delete a customer with orders. Please delete orders first.");
                e.Cancel = true;    // avoid the RI error
            }
        }

        private void ordersGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            if (lineitemsGridView.Rows.Count == 1)
                tblOrdersDels.Rows.Add(ordersGridView.CurrentRow.Cells["customer_id"].Value,
                                        ordersGridView.CurrentRow.Cells["order_id"].Value);
            else
            {
                MessageBox.Show("You can not delete an order with lineitems. Please dleete lineitems first.");
                e.Cancel = true;
            }
        }

        private void lineitemsGridView_UserDeletingRow(object sender, DataGridViewRowCancelEventArgs e)
        {
            tblLineItemsDels.Rows.Add(lineitemsGridView.CurrentRow.Cells["order_id"].Value,
                                        lineitemsGridView.CurrentRow.Cells["lineitem"].Value);
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            SqlConnection myCon = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");
            myCon.Open();

            // we start with the inserts and the root parent
            myCommand = new SqlCommand("insert into customers " +
                                        "   (customer_id, first_name, last_name, email, telephone) " +
                                        "select isnull(max(customer_id)+1,1), @first_name, @last_name, @email, @telephone " +
                                        "from   customers ", myCon);
            foreach (DataRow myRow in tblCustomers.Rows)
            {
                if (myRow.RowState == DataRowState.Added) // come on that is so cool
                {
                    myCommand.Parameters.AddWithValue("@first_name", myRow["first_name"]);
                    myCommand.Parameters.AddWithValue("@last_name", myRow["last_name"]);
                    myCommand.Parameters.AddWithValue("@email", myRow["email"]);
                    myCommand.Parameters.AddWithValue("@telephone", myRow["telephone"]);

                    myCommand.ExecuteNonQuery(); // run SQL without return set
                    myCommand.Parameters.Clear();
                }
            }

            foreach (DataRow myRow in tblOrders.Rows)
            {
                if (myRow.RowState == DataRowState.Added)
                {
                    // what customer_id value do we use, new or previous
                    int myCustomer_id = 0;
                    if (myRow["customer_id"].ToString() == "")  // new order on new customer
                    {
                        myCommand = new SqlCommand("select isnull(max(customer_id)+1,1) from customers", myCon);
                        myCustomer_id = (int)myCommand.ExecuteScalar(); // return single value
                    }
                    else
                        myCustomer_id = (int)myRow["customer_id"];

                    // do the insert to the orders table
                    myCommand = new SqlCommand("insert into orders " +
                                               "    (customer_id, order_id, order_date) " +
                                               "select @customer_id, isnull(max(order_id)+1,1), getdate() " +
                                               "from   orders ", myCon);
                    myCommand.Parameters.AddWithValue("@customer_id", myCustomer_id);
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }
        
            // now the lineitem inserts
            foreach (DataRow myRow in tblLineItems.Rows)
            {
                int myOrder_id;
                if (myRow.RowState == DataRowState.Added)
                {
                    if (myRow["order_id"].ToString() == "") // new order
                    {
                        myCommand = new SqlCommand("select max(order_id) from orders", myCon); // would have created this order_id above
                        myOrder_id = (int)myCommand.ExecuteScalar();
                    }
                    else // new lineitem on old order
                        myOrder_id = (int)myRow["order_id"];

                    myCommand = new SqlCommand("insert into order_lineitems " +
                                               "        (order_id, lineitem, product_id, order_quantity, extended_price) " +
                                               "select  @order_id, isnull(max(lineitem)+1,1), @product_id, @order_quantity, @extended_price " +
                                               "from    order_lineitems " +
                                               "where   order_id = @order_id", myCon);
                    myCommand.Parameters.AddWithValue("@order_id", myOrder_id.ToString());
                    myCommand.Parameters.AddWithValue("product_id", myRow["product_id"].ToString());
                    myCommand.Parameters.AddWithValue("order_quantity", myRow["order_quantity"].ToString()); 
                    myCommand.Parameters.AddWithValue("extended_price", myRow["extended_price"].ToString());
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }

            // now we do the deletes from leaf to root
            foreach (DataRow myRow in tblLineItemsDels.Rows)
            {
                if (myRow["order_id"].ToString() != "" && myRow["lineitem"].ToString() != "") // old lineitem deleted
                {
                    myCommand = new SqlCommand("delete from order_lineitems where order_id = @order_id and lineitem = @lineitem",myCon);
                    myCommand.Parameters.AddWithValue("@order_id",myRow["order_id"].ToString());
                    myCommand.Parameters.AddWithValue("@lineitem", myRow["lineitem"].ToString());
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }

            foreach (DataRow myRow in tblOrdersDels.Rows)
            {
                if (myRow["order_id"].ToString() != "")
                {
                    myCommand = new SqlCommand("delete from orders where order_id = @order_id", myCon);
                    myCommand.Parameters.AddWithValue("@order_id", myRow["order_id"].ToString());
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }

            foreach (DataRow myRow in tblCustomersDels.Rows)
            {
                if (myRow["customer_id"].ToString() != "")
                {
                    myCommand = new SqlCommand("delete from customers where customer_id = @customer_id", myCon);
                    myCommand.Parameters.AddWithValue("@customer_id", myRow["customer_id"].ToString());
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }

            // we will use RowState to determine which rows were updated
            // note that table order does not matter here because all keys are fake IDs and therefore never updated
            foreach (DataRow myRow in tblCustomers.Rows)
            {
                if (myRow.RowState == DataRowState.Modified)
                {
                    myCommand = new SqlCommand("update  customers " +
                                               "set     first_name = @first_name, " +
                                               "        last_name = @last_name, " +
                                               "        email = @email, " +
                                               "        telephone = @telephone " +
                                               "where   customer_id = @customer_id", myCon);
                    myCommand.Parameters.AddWithValue("@first_name", myRow["first_name"]);
                    myCommand.Parameters.AddWithValue("@last_name", myRow["last_name"]);
                    myCommand.Parameters.AddWithValue("@email", myRow["email"]);
                    myCommand.Parameters.AddWithValue("@telephone", myRow["telephone"]);
                    myCommand.Parameters.AddWithValue("@customer_id", myRow["customer_id"]);
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }

            // do not need to worry about orders as none of the fields are user supplied

            foreach (DataRow myRow in tblLineItems.Rows)
            {
                if (myRow.RowState == DataRowState.Modified)
                {
                    myCommand = new SqlCommand("update  order_lineitems " +
                                               "set     product_id = (select product_id from products where product_desc = @product_desc), " +
                                               "        order_quantity = @order_quantity, " +
                                               "        extended_price = @extended_price " +
                                               "where   order_id = @order_id " +
                                               "and     lineitem = @lineitem ", myCon);
                    myCommand.Parameters.AddWithValue("@product_desc",myRow["product_desc"]);
                    myCommand.Parameters.AddWithValue("@order_quantity", myRow["order_quantity"]);
                    myCommand.Parameters.AddWithValue("@extended_price", myRow["extended_price"]);
                    myCommand.Parameters.AddWithValue("@order_id", myRow["order_id"]);
                    myCommand.Parameters.AddWithValue("@lineitem", myRow["lineitem"]);
                    myCommand.ExecuteNonQuery();
                    myCommand.Parameters.Clear();
                }
            }

            MessageBox.Show("Updates were successfully written to the database.");
        }

        private void lineitemsGridView_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            combo = e.Control as ComboBox;

            if (combo != null)
            {
                // remove any event handler if it already exists
                combo.SelectedIndexChanged -= new EventHandler(combo_SelectedIndexChanged);

                // so now you can safely add it 
                combo.SelectedIndexChanged += combo_SelectedIndexChanged;

            }
        }

        private void combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = (sender as ComboBox).SelectedItem.ToString();
            lineitemsGridView.CurrentRow.Cells["product_desc"].Value = selected;

            // now we need to synch original product_desc and product_id columns
            foreach (DataRow myRow in tblProducts.Rows)
            {
                if (lineitemsGridView.CurrentRow.Cells["product_desc"].Value == myRow["product_desc"].ToString())
                    lineitemsGridView.CurrentRow.Cells["product_id"].Value = myRow["product_id"].ToString();
            }
        }

        private void customersGridView_SelectionChanged(object sender, EventArgs e)
        {
            SelectionChanged();
        }

        private void ordersGridView_SelectionChanged(object sender, EventArgs e)
        {
            SelectionChanged();
        }

        private void SelectionChanged()
        {
            SqlConnection myCon2 = new SqlConnection(@"Data Source = DESKTOP-FPUC9GF\SQLEXPRESS; Initial Catalog = Orders_DB; Integrated Security = true;");

            // now let's replace that product_id field with a dropdown
            SqlDataAdapter myDA4 = new SqlDataAdapter("select product_id, product_desc from products order by product_desc", myCon2);
            tblProducts = new DataTable("tblProducts");
            myDA4.Fill(tblProducts);

            // dropdown wants an ArrayList as it's datasource
            ArrayList StringList = new ArrayList();

            // populate that arraylist from tblproducts
            foreach (DataRow row in tblProducts.Rows)
            {
                StringList.Add(row["product_desc"].ToString());
            }

            // now add a dropdown to that new lineitems grid column
            for (int i = 0; i < lineitemsGridView.Rows.Count - 1; i++)
            {
                var myCell = new DataGridViewComboBoxCell();    // create an instance of a ComboBox appropriate for use in a datagrid cell
                myCell.DataSource = StringList; // populate the list of options
                lineitemsGridView.Rows[i].Cells[6] = myCell;    // go ahead and populate the new column
            }

            // now set the selected value equal to prev product_desc value
            for (int i = 0; i < lineitemsGridView.Rows.Count - 1; i++)
            {
                for (int j = 0; j < StringList.Count; j++)
                {
                    if (StringList[j].ToString() == lineitemsGridView.Rows[i].Cells[4].Value.ToString())    // found a match
                        lineitemsGridView.Rows[i].Cells[6].Value = StringList[j];
                }
            }

            myCon2.Close();
        }      
    }
}
