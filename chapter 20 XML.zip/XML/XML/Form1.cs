﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;

namespace XML
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            // too rudamentary, let's play with better toys
            /* DataSet myDS = new DataSet();
            myDS.ReadXml(@"D:\documents\C# From Beginner to Pro\chapter 20 XML\products.xml");
            dataGridView1.DataSource = myDS.Tables[0]; */

            dataGridView1.Columns.Add("product_ID", "Product ID");
            dataGridView1.Columns.Add("product_desc", "Product Desc");
            dataGridView1.Columns.Add("product_name", "Product Name");
            dataGridView1.Columns.Add("quantity_on_hand", "QOH");
            dataGridView1.Columns.Add("product_length", "Length");
            dataGridView1.Columns.Add("product_width", "Width");

            XmlDocument myDoc = new XmlDocument();
            myDoc.Load(@"D:\documents\C# From Beginner to Pro\chapter 20 XML\products.xml");

            // create an array of nodes of tag name product
            XmlNodeList elemList = myDoc.GetElementsByTagName("product");

            foreach (XmlNode myNode in elemList)
            {
                int myIndex = dataGridView1.Rows.Add();
                dataGridView1.Rows[myIndex].Cells[0].Value = myNode.Attributes["id"].Value.ToString();
                dataGridView1.Rows[myIndex].Cells[1].Value = myNode["product_desc"].InnerText.ToString();
                dataGridView1.Rows[myIndex].Cells[2].Value = myNode["product_name"].InnerText.ToString();
                dataGridView1.Rows[myIndex].Cells[3].Value = myNode["quantity_on_hand"].InnerText.ToString();
                dataGridView1.Rows[myIndex].Cells[4].Value = myNode["product_length"].InnerText.ToString();
                dataGridView1.Rows[myIndex].Cells[5].Value = myNode["product_width"].InnerText.ToString();
            }
        }

        private void submitButton_Click(object sender, EventArgs e)
        {
            // create the root node as <products>
            XmlDocument myDoc = new XmlDocument();
            XmlNode myRoot = myDoc.CreateElement("products");
            myDoc.AppendChild(myRoot);

            // now add in the child nodes
            foreach (DataGridViewRow myRow in dataGridView1.Rows)
            {
                if (myRow.Cells[0].Value != null)
                {
                    // create a new product tag w/ id attribute
                    XmlNode myProduct = myDoc.CreateElement("product");
                    XmlAttribute myAttribute = myDoc.CreateAttribute("id");
                    myAttribute.Value = myRow.Cells[0].Value.ToString();
                    myProduct.Attributes.Append(myAttribute);
                    myRoot.AppendChild(myProduct);

                    // create child elements
                    XmlElement desc = myDoc.CreateElement("product_desc");
                    desc.InnerText = myRow.Cells[1].Value.ToString();
                    myProduct.AppendChild(desc);

                    XmlElement name = myDoc.CreateElement("product_name");
                    name.InnerText = myRow.Cells[1].Value.ToString();
                    myProduct.AppendChild(name);

                    XmlElement qoh = myDoc.CreateElement("quantity_on_hane");
                    qoh.InnerText = myRow.Cells[2].Value.ToString();
                    myProduct.AppendChild(qoh);

                    XmlElement l = myDoc.CreateElement("product_length");
                    l.InnerText = myRow.Cells[3].Value.ToString();
                    myProduct.AppendChild(l);

                    XmlElement w = myDoc.CreateElement("product_width");
                    w.InnerText = myRow.Cells[4].Value.ToString();
                    myProduct.AppendChild(w);
                }
            }

            File.Delete(@"D:\documents\C# From Beginner to Pro\chapter 20 XML\products.xml");
            myDoc.Save(@"D:\documents\C# From Beginner to Pro\chapter 20 XML\products.xml");

            MessageBox.Show("Contents of data grid have been saved to an external XML file.");
        }
    }
}
