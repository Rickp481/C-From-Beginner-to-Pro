﻿using System;

namespace boolean_data_type
{
    class Program
    {
        static void Main(string[] args)
        {
            bool a = true, b = true, c = false, d = false;
            bool? e = null, f = null, g = null;

            Console.WriteLine("a = true, b = true therefore a && b = {0}", a && b);
            Console.WriteLine("a = true, c = false therefore a && c = {0}", a && c);
            Console.WriteLine("c = false, d = false therefore c && d = {0}", c && d);

            Console.WriteLine("a = true, b = true therefore a || b = {0}", a || b);
            Console.WriteLine("a = true, c = false therefore a || c = {0}", a || c);
            Console.WriteLine("c = false, d = false therefore c || d = {0}", c || d);

            Console.WriteLine("a = true, b = true therefore a ^ b = {0}", a ^ b);
            Console.WriteLine("a = true, c = false therefore a ^ c = {0}", a ^ c);
            Console.WriteLine("c = false, d = false therefore c ^ d = {0}", c ^ d);

            Console.WriteLine("a = true therefore !a = {0}", !a );
            Console.WriteLine("c = false therefore !c = {0}", !c);

            Console.WriteLine("");
            Console.WriteLine("Now we go to the 3-state truth table");
            Console.WriteLine("");

            Console.WriteLine("a = true, e = null therefore a & e = {0}", a & e);
            Console.WriteLine("a = true, e = null therefore a | e = {0}", a | e);
            Console.WriteLine("c = false, e = null therefore c & e = {0}", c & e);
            Console.WriteLine("c = false, e = null therefore c | e = {0}", c | e);
            Console.WriteLine("e = null, f = null therefore e & f = {0}", e & f);
            Console.WriteLine("e = null, f = null therefore e | f = {0}", e | f);
            Console.WriteLine("e = null therefore !e = {0}", !e);

            g = e & f;
            if (g == null) Console.WriteLine("Better than leaving a result unknown");

            Console.ReadLine();
        }
    }
}
