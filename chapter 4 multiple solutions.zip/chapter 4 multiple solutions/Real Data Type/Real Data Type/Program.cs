﻿using System;

namespace Real_Data_Type
{
    class Program
    {
        static void Main(string[] args)
        {

            double a = 1.5, b = -6.00, c = 10.25e-5;
            double d, e, f, g, h, i, j;

            d = a + b;
            e = a - b;
            f = a * b;
            g = a / b;
            h = a % b;
            i = Math.Pow(a, b); // a to the b power

            Console.WriteLine("a = {0}, b = {1}, c = {2}", a, b, c);
            Console.WriteLine("a + b = {0}", d);
            Console.WriteLine("a - b = {0}", e);
            Console.WriteLine("a * b = {0}", f);
            Console.WriteLine("a / b = {0}", g);
            Console.WriteLine("a mod b = {0}", h);
            Console.WriteLine("a exponent b = {0}", i);

            Console.WriteLine("");

            Console.WriteLine("add in the relational operators");
            if (a == b) Console.WriteLine("a == b is true");
            if (a != b) Console.WriteLine("a != b is true");
            if (a < b) Console.WriteLine("a < b is true");
            if (a <= b) Console.WriteLine("a <= b is true");
            if (a > b) Console.WriteLine("a > b is true");
            if (a >= b) Console.WriteLine("a >= b is true");

            Console.ReadLine();
        }
    }
}
