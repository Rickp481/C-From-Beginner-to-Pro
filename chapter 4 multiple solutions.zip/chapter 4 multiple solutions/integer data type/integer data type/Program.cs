﻿using System;

namespace integer_data_type
{
    class Program
    {
        static void Main(string[] args)
        {
            // variable definition
            int a, b, c;
            int d = -10, e = -15, f = -20;
            int g, h, i, j;

            // variable assignment
            a = 10;
            b = 5;
            c = 0;

            Console.WriteLine("a = {0}, b = {1}, c = {2}", a, b, c);

            Console.WriteLine("");
            Console.WriteLine("About to reassign variable c");
            Console.WriteLine("");

            /* variable reassignment */
            c = a - b;
            d = e + f;
            g = e * f;  // a single asterisk is used to denote the multiplication operator
            h = a / c;  // a single backslash is used to denote the division operator
            i = f % e;  // a single percentage sign denotes the modulo operator

            // please note the two types of comments
            // this is single line comment
            /* whereas this is used for one or more lines of comment */

            Console.WriteLine("a = {0}, b = {1}, c = {2}", a, b, c);
            Console.WriteLine("d = {0}, e = {1}, f = {2}, g = {3}, h = {4}, i = {5}", d, e, f, g, h,    i); // note free use of white space
            Console.ReadLine();
        }
    }
}
