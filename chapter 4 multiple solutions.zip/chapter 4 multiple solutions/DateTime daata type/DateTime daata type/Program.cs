﻿using System;

namespace DateTime_daata_type
{
    class Program
    {
        static void Main(string[] args)
        {
            // default datetime format
            DateTime myNow = DateTime.Now;
            Console.WriteLine("Now = myNow = {0}", myNow);

            DateTime myDate = new DateTime(2020, 05, 19);
            Console.WriteLine("myDate = {0}", myDate);

            DateTime myDate2 = new DateTime(2021, 05, 19, 15, 41, 10);
            Console.WriteLine("myDate2 = {0}", myDate2);

            Console.WriteLine(myDate2.Day);
            Console.WriteLine(myDate2.Month);
            Console.WriteLine(myDate2.ToString("MM'-'dd'-'yyyy"));
            Console.WriteLine(myDate2.ToString("MMMM'-'dd'-'yyyy"));
            Console.WriteLine(myDate2.ToString("MM'-'dddd'-'yyyy"));

            // date arithmetic
            Console.WriteLine("");

            TimeSpan ts = myDate2.Subtract(myDate);
            Console.WriteLine("Timespan between myDate and myDate2 is {0}", ts);

            Console.ReadLine();
        }
    }
}
