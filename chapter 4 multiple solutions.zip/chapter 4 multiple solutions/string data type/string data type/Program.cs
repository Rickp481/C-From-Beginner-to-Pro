﻿using System;

namespace string_data_type
{
    class Program
    {
        static void Main(string[] args)
        {
            string a = "Rick Phillips", b = " is the man";

            // concatenation operator
            Console.WriteLine(a + b);

            // IndexOf with one parameter
            Console.WriteLine("The first occurence of P in variable a is at position {0} ", a.IndexOf("P"));

            // IndexOf with two parameters
            Console.WriteLine("The second occurence of l in variable a is at position {0} ", a.IndexOf("l", 2));

            // Substring with one parameter
            Console.WriteLine("Substring of variable a starting at position 6 {0} ", a.Substring(6));

            // Substring with two parameters
            Console.WriteLine("Substring of variable a starting at position 6 for 4 characters {0} ", a.Substring(6,4));

            // you can only do equality tests on strings, GT, GE, LT, LE are not valid
            if (a == b) Console.WriteLine("a == b is true");
            if (a != b) Console.WriteLine("a != b is true");
        }
    }
}
