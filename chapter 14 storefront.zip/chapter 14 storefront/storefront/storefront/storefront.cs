﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace storefront
{
    public class car_pic
    {
        public int ID;
        public string filename;
    }

    public class car_vid
    {
        public int ID;
        public string filename;
        public string thumbnail;
    }

    public class car
    {
        public int ID;
        public string manufacturer;
        public string model;
        public string description;
        public int price;
        public int horsepower;
        public double zero_to_sixty;
        public int top_speed;
        public bool passed_search;
        public int pic_count;
        public int vid_count;
        public car_pic[] pics = new car_pic[20];
        public car_vid[] vids = new car_vid[20];
    }
}
