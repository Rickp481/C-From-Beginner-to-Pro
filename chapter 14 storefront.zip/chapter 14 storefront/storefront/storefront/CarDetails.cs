﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace storefront
{
    public partial class CarDetails : Form
    {
        string car_pic_path = @"D:\documents\C# From Beginner to Pro\chapter 14 storefront\cars\";
        car my_car = new car();
        Font my_font = new Font(FontFamily.GenericMonospace,10,FontStyle.Regular);
        Font my_font2 = new Font(FontFamily.GenericMonospace, 14, FontStyle.Bold);

        PictureBox pb1 = new PictureBox();
        PictureBox pic1 = new PictureBox();
        PictureBox pic2 = new PictureBox();
        PictureBox pic3 = new PictureBox();
        PictureBox pic4 = new PictureBox();

        PictureBox thumb1 = new PictureBox();
        PictureBox thumb2 = new PictureBox();
        PictureBox thumb3 = new PictureBox();
        PictureBox thumb4 = new PictureBox();

        public CarDetails(car this_car)
        {
            InitializeComponent();
            my_car = this_car;
        }

        private void CarDetails_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1210, 800);
            this.Text = "Car Details - " + my_car.manufacturer + " " + my_car.model;

            // build GUI
            AddLogo();
            AddDetails();
        }

        private void AddDetails()
        {
            // add the big image in the top center
            Image img1 = Image.FromFile(car_pic_path + my_car.pics[0].filename);
            pb1.Image = img1;
            pb1.Location = new Point(400, 150);
            pb1.Size = new Size(450, 250);
            pb1.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb1);

            // we have already added video player via designer so now we can reference it as a regular class object
            axWindowsMediaPlayer1.Size = new Size(450,250);
            axWindowsMediaPlayer1.Location = new Point(400,150);
            axWindowsMediaPlayer1.Visible = false; // by default we will show an image

            // add pictureboxes to hold up to 4 images and 4 videos (we will not bother with randomization if n > 4
            AddThumbNails();

            // add the descriptive information at the bottom
            AddDescriptors();

            // add the I want to buy it button
            Button buy_it = new Button();
            buy_it.Text = "I want IT!!!";
            buy_it.BackColor = Color.LightPink;
            buy_it.Location = new Point(525,650);
            buy_it.Size = new Size(150, 50);
            buy_it.Font = my_font;
            buy_it.Click += new EventHandler(ShowBuyACar);
            this.Controls.Add(buy_it);
        }

        private void ShowBuyACar(object sender, EventArgs e)
        {
            this.Hide();
            BuyACar newPage = new BuyACar();
            newPage.ShowDialog();
            this.Close();
        }


        private void AddDescriptors()
        {
            Label manufacturer = new Label();
            manufacturer.Font = my_font2;
            manufacturer.Text = "Manufacturer: ";
            manufacturer.Location = new Point(200, 450);
            manufacturer.AutoSize = true;
            this.Controls.Add(manufacturer);

            Label manufacturer2 = new Label();
            manufacturer2.Font = my_font2;
            manufacturer2.Text = my_car.manufacturer;
            manufacturer2.Location = new Point(400, 450);
            manufacturer2.AutoSize = true;
            this.Controls.Add(manufacturer2);

            Label model = new Label();
            model.Font = my_font2;
            model.Text = "Model: ";
            model.Location = new Point(200, 480);
            model.AutoSize = true;
            this.Controls.Add(model);

            Label model2 = new Label();
            model2.Font = my_font2;
            model2.Text = my_car.model;
            model2.Location = new Point(400, 480);
            model2.AutoSize = true;
            this.Controls.Add(model2);

            Label price = new Label();
            price.Font = my_font2;
            price.Text = "Price: ";
            price.Location = new Point(200, 510);
            price.AutoSize = true;
            this.Controls.Add(price);

            Label price2 = new Label();
            price2.Font = my_font2;
            price2.Text = my_car.price.ToString("C0");
            price2.Location = new Point(400, 510);
            price2.AutoSize = true;
            this.Controls.Add(price2);

            Label horsepower = new Label();
            horsepower.Font = my_font2;
            horsepower.Text = "Horsepower: ";
            horsepower.Location = new Point(825, 450);
            horsepower.AutoSize = true;
            this.Controls.Add(horsepower);

            Label horsepower2 = new Label();
            horsepower2.Font = my_font2;
            horsepower2.Text = my_car.horsepower.ToString();
            horsepower2.Location = new Point(975, 450);
            horsepower2.AutoSize = true;
            this.Controls.Add(horsepower2);

            Label accel = new Label();
            accel.Font = my_font2;
            accel.Text = "0 to 60  mph: ";
            accel.Location = new Point(825, 480);
            accel.AutoSize = true;
            this.Controls.Add(accel);

            Label accel2 = new Label();
            accel2.Font = my_font2;
            accel2.Text = my_car.zero_to_sixty.ToString("0.##"); // display with up to 2 decimal points
            accel2.Location = new Point(975, 480);
            accel2.AutoSize = true;
            this.Controls.Add(accel2);

            Label top_speed = new Label();
            top_speed.Font = my_font2;
            top_speed.Text = "Top speed: ";
            top_speed.Location = new Point(825, 510);
            top_speed.AutoSize = true;
            this.Controls.Add(top_speed);

            Label top_speed2 = new Label();
            top_speed2.Font = my_font2;
            top_speed2.Text = my_car.top_speed.ToString();
            top_speed2.Location = new Point(975, 510);
            top_speed2.AutoSize = true;
            this.Controls.Add(top_speed2);

            TextBox tb1 = new TextBox();
            tb1.Multiline = true;
            tb1.Font = my_font2;
            tb1.Size = new Size(850, 60);
            tb1.Location = new Point(200, 575);
            tb1.Text = my_car.description;
            tb1.Enabled = false;
            this.Controls.Add(tb1);
        }

        private void AddThumbNails()
        {
            Label l1 = new Label();
            l1.Font = my_font;
            l1.Location = new Point(275, 150);
            l1.Text = "Pics";
            this.Controls.Add(l1);

            Label l2 = new Label();
            l2.Font = my_font;
            l2.Location = new Point(925, 150);
            l2.Text = "Videos";
            this.Controls.Add(l2);

            pic1.Location = new Point(275, 175);
            pic1.Size = new Size(75, 50);
            pic1.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.pics[1] != null)
            {
                Image img2 = Image.FromFile(car_pic_path + my_car.pics[1].filename);
                pic1.Image = img2;
            }
            else pic1.Visible = false;
            pic1.Click += new EventHandler(ShowNewImage);
            this.Controls.Add(pic1);

            pic2.Location = new Point(275, 250);
            pic2.Size = new Size(75, 50);
            pic2.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.pics[2] != null)
            {
                Image img3 = Image.FromFile(car_pic_path + my_car.pics[2].filename);
                pic2.Image = img3;
            }
            else pic2.Visible = false;
            pic2.Click += new EventHandler(ShowNewImage);
            this.Controls.Add(pic2);

            pic3.Location = new Point(275, 325);
            pic3.Size = new Size(75, 50);
            pic3.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.pics[3] != null)
            {
                Image img4 = Image.FromFile(car_pic_path + my_car.pics[3].filename);
                pic3.Image = img4;
            }
            else pic3.Visible = false;
            pic3.Click += new EventHandler(ShowNewImage);
            this.Controls.Add(pic3);

            pic4.Location = new Point(275, 400);
            pic4.Size = new Size(75, 50);
            pic4.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.pics[4] != null)
            {
                Image img5 = Image.FromFile(car_pic_path + my_car.pics[4].filename);
                pic4.Image = img5;
            }
            else pic4.Visible = false;
            pic4.Click += new EventHandler(ShowNewImage);
            this.Controls.Add(pic4);

            thumb1.Location = new Point(925, 175);
            thumb1.Size = new Size(75, 50);
            thumb1.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.vids[0] != null)
            {
                Image img5 = Image.FromFile(car_pic_path + my_car.vids[0].thumbnail);
                thumb1.Image = img5;
            }
            else thumb1.Visible = false;
            thumb1.Click += (sender2, e2) => PlayVideo(sender2, e2, 0); // use the delegate
            this.Controls.Add(thumb1);

            thumb2.Location = new Point(925, 250);
            thumb2.Size = new Size(75, 50);
            thumb2.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.vids[1] != null)
            {
                Image img6 = Image.FromFile(car_pic_path + my_car.vids[1].thumbnail);
                thumb2.Image = img6;
            }
            else thumb2.Visible = false;
            thumb2.Click += (sender2, e2) => PlayVideo(sender2, e2, 1); // use the delegate
            this.Controls.Add(thumb2);

            thumb3.Location = new Point(925, 325);
            thumb3.Size = new Size(75, 50);
            thumb3.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.vids[2] != null)
            {
                Image img7 = Image.FromFile(car_pic_path + my_car.vids[2].thumbnail);
                thumb3.Image = img7;
            }
            else thumb3.Visible = false;
            thumb3.Click += (sender2, e2) => PlayVideo(sender2, e2, 2); // use the delegate
            this.Controls.Add(thumb3);

            thumb4.Location = new Point(925, 400);
            thumb4.Size = new Size(75, 50);
            thumb4.SizeMode = PictureBoxSizeMode.StretchImage;
            if (my_car.vids[3] != null)
            {
                Image img8 = Image.FromFile(car_pic_path + my_car.vids[3].thumbnail);
                thumb4.Image = img8;
            }
            else thumb4.Visible = false;
            thumb4.Click += (sender2, e2) => PlayVideo(sender2, e2, 3); // use the delegate
            this.Controls.Add(thumb4);
        }

        private void ShowNewImage(object sender, EventArgs e)
        {
            pb1.Visible = true;
            axWindowsMediaPlayer1.Visible = false;
            if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPlaying) axWindowsMediaPlayer1.Ctlcontrols.stop();
            Image temp = pb1.Image;
            PictureBox which_thumbnail = (PictureBox)sender;
            pb1.Image = which_thumbnail.Image;
            which_thumbnail.Image = temp;
        }

        private void PlayVideo(object sender, EventArgs e, int which_video)
        {
            pb1.Visible = false;
            if (axWindowsMediaPlayer1.playState == WMPLib.WMPPlayState.wmppsPlaying) axWindowsMediaPlayer1.Ctlcontrols.stop();
            axWindowsMediaPlayer1.Visible = true;
            PictureBox which_thumbnail = (PictureBox)sender;
            axWindowsMediaPlayer1.URL = car_pic_path + my_car.vids[which_video].filename;
        }

        private void AddLogo()
        {
            Image logo = Image.FromFile(@"D:\documents\C# From Beginner to Pro\chapter 14 storefront\images\logo.jpg");
            PictureBox lg = new PictureBox();
            lg.Image = logo;
            lg.Size = new Size(325, 125);
            lg.Location = new Point(0, 0);
            lg.SizeMode = PictureBoxSizeMode.StretchImage;
            lg.Click += new EventHandler(LogoClick);

            this.Controls.Add(lg);
        }

        private void LogoClick(object sender, EventArgs e)
        {
            HomePage hp = new HomePage();
            this.Hide();
            hp.ShowDialog();
            this.Close();
        }

    }
}
