﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace storefront
{
    public partial class HomePage : Form
    {
        string car_pic_path = @"D:\documents\C# From Beginner to Pro\chapter 14 storefront\cars\";
        Random random = new Random();

        car[] my_cars = new car[20];
        int[] displayed_cars = new int[9];
        ToolTip t1 = new ToolTip();

        TextBox search_textbox = new TextBox();

        public HomePage()
        {
            InitializeComponent();
        }

        private void HomePage_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1210, 800);
            AddLogo();
            AddSearchBar();
            AddSwoosh();
            LoadCars();
            AddGrid();
        }

        private void AddGrid()
        {
            TableLayoutPanel parent_grid = new TableLayoutPanel();
            parent_grid.CellBorderStyle = TableLayoutPanelCellBorderStyle.InsetDouble;
            parent_grid.Location = new Point(10,160);
            parent_grid.Size = new Size(1175,525);
            this.Controls.Add(parent_grid);

            ToolTip t1 = new ToolTip();
            int counter = 0;
            int start_index = random.Next(12);  

            for (int i =0; i < 3; i++)
            {
                for (int j=0; j < 3; j++)
                {
                    TableLayoutPanel child_grid = new TableLayoutPanel();
                    child_grid.Size = new Size(380, 165);
                    child_grid.RowCount = 3;
                    child_grid.ColumnCount = 1;
                    child_grid.CellBorderStyle = TableLayoutPanelCellBorderStyle.None;
                    parent_grid.Controls.Add(child_grid,i,j);   // add object at cell i,j

                    PictureBox pic = new PictureBox();
                    Image img = Image.FromFile(car_pic_path + my_cars[start_index + counter].pics[0].filename);
                    pic.Image = img;
                    pic.Size = new Size(395,110);
                    pic.SizeMode = PictureBoxSizeMode.StretchImage;
                    t1.SetToolTip(pic, "Click any image to see details.");
                    

                    // add event handler and delegate via lambda operator
                    if (i == 0 && j == 0) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 0].ID);
                    else if (i == 0 && j == 1) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 1].ID);
                    else if (i == 0 && j == 2) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 2].ID);
                    else if (i == 1 && j == 0) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 3].ID);
                    else if (i == 1 && j == 1) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 4].ID);
                    else if (i == 1 && j == 2) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 5].ID);
                    else if (i == 2 && j == 0) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 6].ID);
                    else if (i == 2 && j == 1) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 7].ID);
                    else if (i == 2 && j == 2) pic.Click += (sender2, e2) => ImageWasClicked(sender2, e2, my_cars[start_index + 8].ID);

                    child_grid.Controls.Add(pic, 0, 0);

                    Label l1 = new Label();
                    l1.Text = my_cars[start_index + counter].manufacturer + " " + my_cars[start_index + counter].model;
                    Font my_font = new Font(FontFamily.GenericSansSerif,10,FontStyle.Regular);
                    l1.Font = my_font;
                    child_grid.Controls.Add(l1,0,1);

                    Label l2 = new Label();
                    l2.Text = my_cars[start_index + counter].price.ToString("C0");
                    l2.Font = my_font;
                    child_grid.Controls.Add(l2, 0, 2);

                    displayed_cars[counter] = my_cars[start_index + counter].ID;
                    counter += 1;
                }
            }
        }

        private void ClearCars()
        {
            foreach (Control c in this.Controls)
            {
                if (c is TableLayoutPanel)  // parent
                {
                    foreach (Control d in c.Controls)
                    {
                        if (d is TableLayoutPanel)  // child
                        {
                            foreach(Control e in d.Controls)
                            {
                                if (e is PictureBox)
                                {
                                    PictureBox pb1 = (PictureBox)e; // cast the control to PictureBox
                                    pb1.Image = null;
                                }
                                else if (e is Label)
                                {
                                    Label l1 = (Label)e; // cast the control to Label
                                    l1.Text = "";
                                }
                            }
                        }
                    }
                }
            }
        }

        private void WhichCars()
        {
            // clear out all previously displayed cars
            Array.Clear(displayed_cars, 0, displayed_cars.Length);

            for (int i = 0; i < displayed_cars.Length; i++) displayed_cars[i] = -1; // indicates no car

            int counter = 0;
            foreach (car a_car in my_cars)
            {
                if (a_car.manufacturer.ToUpper().Contains(search_textbox.Text.ToUpper()) ||
                    a_car.model.ToUpper().Contains(search_textbox.Text.ToUpper()) ||
                    a_car.description.ToUpper().Contains(search_textbox.Text.ToUpper()))    
                {
                    if (counter < 8)    // we only have room to display 9 cars
                    {
                        displayed_cars[counter] = a_car.ID;
                        counter += 1;
                    }
                }
            }
        }

        private void DisplayMatches()
        {
            car this_car = new car();
            if (displayed_cars[0] == -1)
            {
                MessageBox.Show("There were no cars matching your search criterion");
                FillGrid();
            }
            else
            {
                for (int i=0; i< displayed_cars.Length; i++)
                {
                    this_car = null;
                    if (displayed_cars[i] > 0)  // a valid car ID
                    {
                        foreach (car a_car in my_cars)
                        {
                            if (a_car.ID == displayed_cars[i]) this_car = a_car;  // this_car is now pointing to a car to display
                        }
                    }

                    if (this_car != null)
                    {
                        bool applied;
                        foreach(Control a in this.Controls)
                        {
                            applied = false;
                            if (a is TableLayoutPanel) // found parent
                            {
                                foreach (Control b in a.Controls)
                                {
                                    if (b is TableLayoutPanel)  // found child
                                    {
                                        PictureBox p1 = (PictureBox)b.Controls[0];  // we know this because we know order we created objects in child grid
                                        if (p1.Image == null && applied == false)  // then this cell is empty & this car has not been displayed
                                        {
                                            p1.Image = Image.FromFile(car_pic_path + this_car.pics[0].filename);
                                            Label l1 = (Label)b.Controls[1];
                                            l1.Text = this_car.manufacturer + " " + this_car.model;
                                            Label l2 = (Label)b.Controls[2];
                                            l2.Text = this_car.price.ToString("C0");
                                            applied = true;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        private void FillGrid()
        {
            bool applied = false;
            for (int i=0; i<9; i++)
            {
                applied = false;
                foreach (Control a in this.Controls)
                {
                    if (a is TableLayoutPanel) // parent
                    {
                        foreach(Control b in a.Controls)
                        {
                            if (b is TableLayoutPanel)  // child
                            {
                                PictureBox p1 = (PictureBox)b.Controls[0];  // we know this because we know order we created objects in child grid
                                if (p1.Image == null && applied == false)  // then this cell is empty & this car has not been displayed
                                {
                                    p1.Image = Image.FromFile(car_pic_path + my_cars[i].pics[0].filename);
                                    Label l1 = (Label)b.Controls[1];
                                    l1.Text = my_cars[i].manufacturer + " " + my_cars[i].model;
                                    Label l2 = (Label)b.Controls[2];
                                    l2.Text = my_cars[i].price.ToString("C0");
                                    applied = true;
                                }
                            }

                        }
                    }
                }
            }
        }

        private void ImageWasClicked (object sender, EventArgs e, int ID)
        {
            car a_car = new car();
            for (int i=0; i < my_cars.Length; i++)
            {
                if (my_cars[i].ID == ID) a_car = my_cars[i];
            }

            this.Hide();
            CarDetails newPage = new CarDetails(a_car);
            newPage.ShowDialog();
            this.Close();
        }

        private void ClearSearch(object sender, EventArgs e)
        {
            search_textbox.Text = "";
        }

        private void LoadCars()
        {
            my_cars[0] = new car();
            my_cars[0].ID = 1;
            my_cars[0].manufacturer = "Audi";
            my_cars[0].model = "R8";
            my_cars[0].description = "Great little car for those smaller in stature. This is definitely not your car if you are 7' tall.";
            my_cars[0].horsepower = 620;
            my_cars[0].top_speed = 205;
            my_cars[0].zero_to_sixty = 4.3;
            my_cars[0].price = 169900;
            my_cars[0].passed_search = true;
            my_cars[0].pic_count = 1;
            my_cars[0].vid_count = 1;

            my_cars[0].pics[0] = new car_pic();
            my_cars[0].pics[0].ID = 1;
            my_cars[0].pics[0].filename = "Audi R8.jpg";

            my_cars[0].vids[0] = new car_vid();
            my_cars[0].vids[0].ID = 1;
            my_cars[0].vids[0].filename = "Audi R8 v1.mp4";
            my_cars[0].vids[0].thumbnail = "audi R8 thumbnail.jpg";

            my_cars[1] = new car();
            my_cars[1].ID = 2;
            my_cars[1].manufacturer = "BMW";
            my_cars[1].model = "I8";
            my_cars[1].description = "Probably the best appointed car in this entire collection. The I8 is the true luxury car of performance cars.";
            my_cars[1].horsepower = 335;
            my_cars[1].top_speed = 155;
            my_cars[1].zero_to_sixty = 4.2;
            my_cars[1].price = 147500;
            my_cars[1].passed_search = true;
            my_cars[1].pic_count = 2;
            my_cars[1].vid_count = 3;

            my_cars[1].pics[0] = new car_pic();
            my_cars[1].pics[0].ID = 2;
            my_cars[1].pics[0].filename = "BMW I8 Black.jpg";
            my_cars[1].pics[1] = new car_pic();
            my_cars[1].pics[1].ID = 3;
            my_cars[1].pics[1].filename = "BMW I8 Black 2.jpg";

            my_cars[1].vids[0] = new car_vid();
            my_cars[1].vids[0].ID = 2;
            my_cars[1].vids[0].filename = "BMW I8 v1.mp4";
            my_cars[1].vids[0].thumbnail = "bmw I8 thumbnail 1.jpg";
            my_cars[1].vids[1] = new car_vid();
            my_cars[1].vids[1].ID = 3;
            my_cars[1].vids[1].filename = "BMW I8 v2.mp4";
            my_cars[1].vids[1].thumbnail = "bmw I8 thumbnail 2.jpg";
            my_cars[1].vids[2] = new car_vid();
            my_cars[1].vids[2].ID = 4;
            my_cars[1].vids[2].filename = "BMW I8 v3 quirks.mp4";
            my_cars[1].vids[2].thumbnail = "bmw I8 thumbnail 3.jpg";

            my_cars[2] = new car();
            my_cars[2].ID = 3;
            my_cars[2].manufacturer = "BMW";
            my_cars[2].model = "I8";
            my_cars[2].description = "Probably the best appointed car in this entire collection. The I8 is the true luxury car of performance cars.";
            my_cars[2].horsepower = 335;
            my_cars[2].top_speed = 155;
            my_cars[2].zero_to_sixty = 4.2;
            my_cars[2].price = 147500;
            my_cars[2].passed_search = true;
            my_cars[2].pic_count = 1;
            my_cars[2].vid_count = 3;

            my_cars[2].pics[0] = new car_pic();
            my_cars[2].pics[0].ID = 4;
            my_cars[2].pics[0].filename = "bmw I8 blue.jpg";

            my_cars[2].vids[0] = new car_vid();
            my_cars[2].vids[0].ID = 5;
            my_cars[2].vids[0].filename = "BMW I8 v1.mp4";
            my_cars[2].vids[0].thumbnail = "bmw I8 thumbnail 1.jpg";
            my_cars[2].vids[1] = new car_vid();
            my_cars[2].vids[1].ID = 6;
            my_cars[2].vids[1].filename = "BMW I8 v2.mp4";
            my_cars[2].vids[1].thumbnail = "bmw I8 thumbnail 2.jpg";
            my_cars[2].vids[2] = new car_vid();
            my_cars[2].vids[2].ID = 7;
            my_cars[2].vids[2].filename = "BMW I8 v3 quirks.mp4";
            my_cars[2].vids[2].thumbnail = "bmw I8 thumbnail 3.jpg";

            my_cars[3] = new car();
            my_cars[3].ID = 4;
            my_cars[3].manufacturer = "BMW";
            my_cars[3].model = "I8";
            my_cars[3].description = "Probably the best appointed car in this entire collection. The I8 is the true luxury car of performance cars.";
            my_cars[3].horsepower = 335;
            my_cars[3].top_speed = 155;
            my_cars[3].zero_to_sixty = 4.2;
            my_cars[3].price = 147500;
            my_cars[3].passed_search = true;
            my_cars[3].pic_count = 3;
            my_cars[3].vid_count = 3;

            my_cars[3].pics[0] = new car_pic();
            my_cars[3].pics[0].ID = 5;
            my_cars[3].pics[0].filename = "BMW I8 Convertible.jpg";
            my_cars[3].pics[1] = new car_pic();
            my_cars[3].pics[1].ID = 6;
            my_cars[3].pics[1].filename = "BMW I8 Convertible 2.jpg";
            my_cars[3].pics[2] = new car_pic();
            my_cars[3].pics[2].ID = 7;
            my_cars[3].pics[2].filename = "BMW I8 Convertible 3.jpg";

            my_cars[3].vids[0] = new car_vid();
            my_cars[3].vids[0].ID = 8;
            my_cars[3].vids[0].filename = "BMW I8 v1.mp4";
            my_cars[3].vids[0].thumbnail = "bmw I8 thumbnail 1.jpg";
            my_cars[3].vids[1] = new car_vid();
            my_cars[3].vids[1].ID = 9;
            my_cars[3].vids[1].filename = "BMW I8 v2.mp4";
            my_cars[3].vids[1].thumbnail = "bmw I8 thumbnail 2.jpg";
            my_cars[3].vids[2] = new car_vid();
            my_cars[3].vids[2].ID = 10;
            my_cars[3].vids[2].filename = "BMW I8 v3 quirks.mp4";
            my_cars[3].vids[2].thumbnail = "bmw I8 thumbnail 3.jpg";

            my_cars[4] = new car();
            my_cars[4].ID = 5;
            my_cars[4].manufacturer = "BMW";
            my_cars[4].model = "I8";
            my_cars[4].description = "Probably the best appointed car in this entire collection. The I8 is the true luxury car of performance cars.";
            my_cars[4].horsepower = 335;
            my_cars[4].top_speed = 155;
            my_cars[4].zero_to_sixty = 4.2;
            my_cars[4].price = 147500;
            my_cars[4].passed_search = true;
            my_cars[4].pic_count = 2;
            my_cars[4].vid_count = 3;


            my_cars[4].pics[0] = new car_pic();
            my_cars[4].pics[0].ID = 8;
            my_cars[4].pics[0].filename = "BMW I8 White.jpg";
            my_cars[4].pics[1] = new car_pic();
            my_cars[4].pics[1].ID = 9;
            my_cars[4].pics[1].filename = "BMW I8 White 2.jpg";

            my_cars[4].vids[0] = new car_vid();
            my_cars[4].vids[0].ID = 11;
            my_cars[4].vids[0].filename = "BMW I8 v1.mp4";
            my_cars[4].vids[0].thumbnail = "bmw I8 thumbnail 1.jpg";
            my_cars[4].vids[1] = new car_vid();
            my_cars[4].vids[1].ID = 12;
            my_cars[4].vids[1].filename = "BMW I8 v2.mp4";
            my_cars[4].vids[1].thumbnail = "bmw I8 thumbnail 2.jpg";
            my_cars[4].vids[2] = new car_vid();
            my_cars[4].vids[2].ID = 13;
            my_cars[4].vids[2].filename = "BMW I8 v3 quirks.mp4";
            my_cars[4].vids[2].thumbnail = "bmw I8 thumbnail 3.jpg";

            my_cars[5] = new car();
            my_cars[5].ID = 6;
            my_cars[5].manufacturer = "Bugatti";
            my_cars[5].model = "Chiron";
            my_cars[5].description = "This boys and girls is true performance but bring your checkbook because those babies are VERY expensive. You have to ask you cannot afford it.";
            my_cars[5].horsepower = 1479;
            my_cars[5].top_speed = 261;
            my_cars[5].zero_to_sixty = 2.4;
            my_cars[5].price = 2998000;
            my_cars[5].passed_search = true;
            my_cars[5].pic_count = 3;
            my_cars[5].vid_count = 2;

            my_cars[5].pics[0] = new car_pic();
            my_cars[5].pics[0].ID = 10;
            my_cars[5].pics[0].filename = "bugatti chiron 1.jpg";
            my_cars[5].pics[1] = new car_pic();
            my_cars[5].pics[1].ID = 11;
            my_cars[5].pics[1].filename = "bugatti chiron 2.jpg";
            my_cars[5].pics[2] = new car_pic();
            my_cars[5].pics[2].ID = 12;
            my_cars[5].pics[2].filename = "bugatti chiron 3.jpg";

            my_cars[5].vids[0] = new car_vid();
            my_cars[5].vids[0].ID = 14;
            my_cars[5].vids[0].filename = "bugatti chiron v1.mp4";
            my_cars[5].vids[0].thumbnail = "bughatti chiron thumbnail 1.jpg";
            my_cars[5].vids[1] = new car_vid();
            my_cars[5].vids[1].ID = 15;
            my_cars[5].vids[1].filename = "bugatti chiron v2.mp4";
            my_cars[5].vids[1].thumbnail = "bughatti chiron thumbnail 2.jpg";

            my_cars[6] = new car();
            my_cars[6].ID = 7;
            my_cars[6].manufacturer = "Chevrolet";
            my_cars[6].model = "Corvette ZR1";
            my_cars[6].description = "If you are old enough to afford this car then your knees and hips forbid you getting in and out of it. Avoid this car.";
            my_cars[6].horsepower = 755;
            my_cars[6].top_speed = 212;
            my_cars[6].zero_to_sixty = 2.85;
            my_cars[6].price = 125400;
            my_cars[6].passed_search = true;
            my_cars[6].pic_count = 1;
            my_cars[6].vid_count = 1;

            my_cars[6].pics[0] = new car_pic();
            my_cars[6].pics[0].ID = 13;
            my_cars[6].pics[0].filename = "corvette zr1.jpg";

            my_cars[6].vids[0] = new car_vid();
            my_cars[6].vids[0].ID = 16;
            my_cars[6].vids[0].filename = "Corvette ZR1 v1.mp4";
            my_cars[6].vids[0].thumbnail = "corvette zr1 thumbnail.jpg";

            my_cars[7] = new car();
            my_cars[7].ID = 8;
            my_cars[7].manufacturer = "Dodge";
            my_cars[7].model = "Challenger Hellcat";
            my_cars[7].description = "Oh my gosh. Just hang on to your hat and go.";
            my_cars[7].horsepower = 797;
            my_cars[7].top_speed = 203;
            my_cars[7].zero_to_sixty = 3.4;
            my_cars[7].price = 59245;
            my_cars[7].passed_search = true;
            my_cars[7].pic_count = 3;
            my_cars[7].vid_count = 2;

            my_cars[7].pics[0] = new car_pic();
            my_cars[7].pics[0].ID = 14;
            my_cars[7].pics[0].filename = "dodge challenger hellcat 1.jpg";
            my_cars[7].pics[1] = new car_pic();
            my_cars[7].pics[1].ID = 15;
            my_cars[7].pics[1].filename = "dodge challenger 2.jpg";
            my_cars[7].pics[2] = new car_pic();
            my_cars[7].pics[2].ID = 16;
            my_cars[7].pics[2].filename = "dodge challenger 3.jpg";

            my_cars[7].vids[0] = new car_vid();
            my_cars[7].vids[0].ID = 17;
            my_cars[7].vids[0].filename = "Dodge Challenger Hellcat v1.mp4";
            my_cars[7].vids[0].thumbnail = "dodge challenger hellcat thumbnail 1.jpg";
            my_cars[7].vids[1] = new car_vid();
            my_cars[7].vids[1].ID = 18;
            my_cars[7].vids[1].filename = "Dodge Challenger Hellcat v2.mp4";
            my_cars[7].vids[1].thumbnail = "dodge challenger hellcat thumbnail 2.jpg";

            my_cars[8] = new car();
            my_cars[8].ID = 9;
            my_cars[8].manufacturer = "Ferrari";
            my_cars[8].model = "F50";
            my_cars[8].description = "Probably past its prime. Living off its name which previously really meant something. Not so much any more.";
            my_cars[8].horsepower = 512;
            my_cars[8].top_speed = 194;
            my_cars[8].zero_to_sixty = 3.8;
            my_cars[8].price = 3600000;
            my_cars[8].passed_search = true;
            my_cars[8].pic_count = 4;
            my_cars[8].vid_count = 0;

            my_cars[8].pics[0] = new car_pic();
            my_cars[8].pics[0].ID = 17;
            my_cars[8].pics[0].filename = "ferrari f40 1.jpg";
            my_cars[8].pics[1] = new car_pic();
            my_cars[8].pics[1].ID = 18;
            my_cars[8].pics[1].filename = "ferrari f40 2.jpg";
            my_cars[8].pics[2] = new car_pic();
            my_cars[8].pics[2].ID = 19;
            my_cars[8].pics[2].filename = "ferrari f40 3.jpg";
            my_cars[8].pics[3] = new car_pic();
            my_cars[8].pics[3].ID = 20;
            my_cars[8].pics[3].filename = "ferrari f40 4.jpg";

            // my Ferrari has no videos

            my_cars[9] = new car();
            my_cars[9].ID = 10;
            my_cars[9].manufacturer = "Ford";
            my_cars[9].model = "GT";
            my_cars[9].description = "The Ford GT is very rare, a highly coveted collector car and is therefore very expensive for what you are getting.";
            my_cars[9].horsepower = 647;
            my_cars[9].top_speed = 216;
            my_cars[9].zero_to_sixty = 3.0;
            my_cars[9].price = 450000;
            my_cars[9].passed_search = true;
            my_cars[9].pic_count = 3;
            my_cars[9].vid_count = 2;

            my_cars[9].pics[0] = new car_pic();
            my_cars[9].pics[0].ID = 21;
            my_cars[9].pics[0].filename = "Ford GT.jpg";
            my_cars[9].pics[1] = new car_pic();
            my_cars[9].pics[1].ID = 22;
            my_cars[9].pics[1].filename = "Ford GT 2.jpg";
            my_cars[9].pics[2] = new car_pic();
            my_cars[9].pics[2].ID = 23;
            my_cars[9].pics[2].filename = "Ford GT 3.jpg";

            my_cars[9].vids[0] = new car_vid();
            my_cars[9].vids[0].ID = 19;
            my_cars[9].vids[0].filename = "Ford GT v1.mp4";
            my_cars[9].vids[0].thumbnail = "ford GT thumbnail 1.jpg";
            my_cars[9].vids[1] = new car_vid();
            my_cars[9].vids[1].ID = 20;
            my_cars[9].vids[1].filename = "Ford GT v2.mp4";
            my_cars[9].vids[1].thumbnail = "ford GT thumbnail 2.jpg";

            my_cars[10] = new car();
            my_cars[10].ID = 11;
            my_cars[10].manufacturer = "Ford";
            my_cars[10].model = "GT";
            my_cars[10].description = "The Ford GT is very rare, a highly coveted collector car and is therefore very expensive for what you are getting.";
            my_cars[10].horsepower = 647;
            my_cars[10].top_speed = 216;
            my_cars[10].zero_to_sixty = 3.0;
            my_cars[10].price = 450000;
            my_cars[10].passed_search = true;
            my_cars[10].pic_count = 1;
            my_cars[10].vid_count = 2;

            my_cars[10].pics[0] = new car_pic();
            my_cars[10].pics[0].ID = 24;
            my_cars[10].pics[0].filename = "Ford GT black.jpg";

            my_cars[10].vids[0] = new car_vid();
            my_cars[10].vids[0].ID = 21;
            my_cars[10].vids[0].filename = "Ford GT v1.mp4";
            my_cars[10].vids[0].thumbnail = "ford GT thumbnail 1.jpg";
            my_cars[10].vids[1] = new car_vid();
            my_cars[10].vids[1].ID = 22;
            my_cars[10].vids[1].filename = "Ford GT v2.mp4";
            my_cars[10].vids[1].thumbnail = "ford GT thumbnail 2.jpg";

            my_cars[11] = new car();
            my_cars[11].ID = 12;
            my_cars[11].manufacturer = "Ford";
            my_cars[11].model = "GT";
            my_cars[11].description = "The Ford GT is very rare, a highly coveted collector car and is therefore very expensive for what you are getting.";
            my_cars[11].horsepower = 647;
            my_cars[11].top_speed = 216;
            my_cars[11].zero_to_sixty = 3.0;
            my_cars[11].price = 450000;
            my_cars[11].passed_search = true;
            my_cars[11].pic_count = 1;
            my_cars[11].vid_count = 2;

            my_cars[11].pics[0] = new car_pic();
            my_cars[11].pics[0].ID = 25;
            my_cars[11].pics[0].filename = "Ford GT gray.jpg";

            my_cars[11].vids[0] = new car_vid();
            my_cars[11].vids[0].ID = 23;
            my_cars[11].vids[0].filename = "Ford GT v1.mp4";
            my_cars[11].vids[0].thumbnail = "ford GT thumbnail 1.jpg";
            my_cars[11].vids[1] = new car_vid();
            my_cars[11].vids[1].ID = 24;
            my_cars[11].vids[1].filename = "Ford GT v2.mp4";
            my_cars[11].vids[1].thumbnail = "ford GT thumbnail 2.jpg";

            my_cars[12] = new car();
            my_cars[12].ID = 13;
            my_cars[12].manufacturer = "Ford";
            my_cars[12].model = "GT";
            my_cars[12].description = "The Ford GT is very rare, a highly coveted collector car and is therefore very expensive for what you are getting.";
            my_cars[12].horsepower = 647;
            my_cars[12].top_speed = 216;
            my_cars[12].zero_to_sixty = 3.0;
            my_cars[12].price = 450000;
            my_cars[12].passed_search = true;
            my_cars[12].pic_count = 1;
            my_cars[12].vid_count = 2;

            my_cars[12].pics[0] = new car_pic();
            my_cars[12].pics[0].ID = 26;
            my_cars[12].pics[0].filename = "Ford GT white 1.jpg";

            my_cars[12].vids[0] = new car_vid();
            my_cars[12].vids[0].ID = 25;
            my_cars[12].vids[0].filename = "Ford GT v1.mp4";
            my_cars[12].vids[0].thumbnail = "ford GT thumbnail 1.jpg";
            my_cars[12].vids[1] = new car_vid();
            my_cars[12].vids[1].ID = 26;
            my_cars[12].vids[1].filename = "Ford GT v2.mp4";
            my_cars[12].vids[1].thumbnail = "ford GT thumbnail 2.jpg";

            my_cars[13] = new car();
            my_cars[13].ID = 14;
            my_cars[13].manufacturer = "Ford";
            my_cars[13].model = "GT";
            my_cars[13].description = "The Ford GT is very rare, a highly coveted collector car and is therefore very expensive for what you are getting.";
            my_cars[13].horsepower = 647;
            my_cars[13].top_speed = 216;
            my_cars[13].zero_to_sixty = 3.0;
            my_cars[13].price = 450000;
            my_cars[13].passed_search = true;
            my_cars[13].pic_count = 1;
            my_cars[13].vid_count = 2;

            my_cars[13].pics[0] = new car_pic();
            my_cars[13].pics[0].ID = 27;
            my_cars[13].pics[0].filename = "Ford GT yellow.jpg";

            my_cars[13].vids[0] = new car_vid();
            my_cars[13].vids[0].ID = 27;
            my_cars[13].vids[0].filename = "Ford GT v1.mp4";
            my_cars[13].vids[0].thumbnail = "ford GT thumbnail 1.jpg";
            my_cars[13].vids[1] = new car_vid();
            my_cars[13].vids[1].ID = 28;
            my_cars[13].vids[1].filename = "Ford GT v2.mp4";
            my_cars[13].vids[1].thumbnail = "ford GT thumbnail 2.jpg";

            my_cars[14] = new car();
            my_cars[14].ID = 15;
            my_cars[14].manufacturer = "Lexus";
            my_cars[14].model = "LC 500";
            my_cars[14].description = "Again, by the time you can afford this car your joints will not allow you to get in and out of it.";
            my_cars[14].horsepower = 471;
            my_cars[14].top_speed = 168;
            my_cars[14].zero_to_sixty = 4.4;
            my_cars[14].price = 92300;
            my_cars[14].passed_search = true;
            my_cars[14].pic_count = 3;
            my_cars[14].vid_count = 1;

            my_cars[14].pics[0] = new car_pic();
            my_cars[14].pics[0].ID = 28;
            my_cars[14].pics[0].filename = "lexus lc 500.jpg";
            my_cars[14].pics[1] = new car_pic();
            my_cars[14].pics[1].ID = 29;
            my_cars[14].pics[1].filename = "lexus lc 500 2.jpg";
            my_cars[14].pics[2] = new car_pic();
            my_cars[14].pics[2].ID = 30;
            my_cars[14].pics[2].filename = "lexus lc 500 3.jpg";

            my_cars[14].vids[0] = new car_vid();
            my_cars[14].vids[0].ID = 29;
            my_cars[14].vids[0].filename = "Lexus LC 500 v1.mp4";
            my_cars[14].vids[0].thumbnail = "lexus lc 500 thumbnail.jpg";

            my_cars[15] = new car();
            my_cars[15].ID = 16;
            my_cars[15].manufacturer = "Masserati";
            my_cars[15].model = "Gran Tourismo";
            my_cars[15].description = "A truly excellent balance between style, performance and comfort. Buy this car!";
            my_cars[15].horsepower = 354;
            my_cars[15].top_speed = 186;
            my_cars[15].zero_to_sixty = 5.8;
            my_cars[15].price = 150380;
            my_cars[15].passed_search = true;
            my_cars[15].pic_count = 5;
            my_cars[15].vid_count = 1;

            my_cars[15].pics[0] = new car_pic();
            my_cars[15].pics[0].ID = 31;
            my_cars[15].pics[0].filename = "masserati 1.jpg";
            my_cars[15].pics[1] = new car_pic();
            my_cars[15].pics[1].ID = 32;
            my_cars[15].pics[1].filename = "masserati 2.jpg";
            my_cars[15].pics[2] = new car_pic();
            my_cars[15].pics[2].ID = 33;
            my_cars[15].pics[2].filename = "masserati 3.jpg";
            my_cars[15].pics[3] = new car_pic();
            my_cars[15].pics[3].ID = 34;
            my_cars[15].pics[3].filename = "masserati 4.jpg";
            my_cars[15].pics[4] = new car_pic();
            my_cars[15].pics[4].ID = 35;
            my_cars[15].pics[4].filename = "masserati 5.jpg";

            my_cars[15].vids[0] = new car_vid();
            my_cars[15].vids[0].ID = 30;
            my_cars[15].vids[0].filename = "Masseratti Gran Tourismo v1.mp4";
            my_cars[15].vids[0].thumbnail = "masseratti gran tourismo thumbnail 1.jpg";


            my_cars[16] = new car();
            my_cars[16].ID = 18;
            my_cars[16].manufacturer = "Ferrari";
            my_cars[16].model = "Enzo";
            my_cars[16].description = "Try to find one. They are super rare.";
            my_cars[16].horsepower = 650;
            my_cars[16].top_speed = 218;
            my_cars[16].zero_to_sixty = 3.6;
            my_cars[16].price = 650000;
            my_cars[16].passed_search = true;
            my_cars[16].pic_count = 2;
            my_cars[16].vid_count = 0;

            my_cars[16].pics[0] = new car_pic();
            my_cars[16].pics[0].ID = 36;
            my_cars[16].pics[0].filename = "Ferrari Enzo 1.jpg";
            my_cars[16].pics[1] = new car_pic();
            my_cars[16].pics[0].ID = 37;
            my_cars[16].pics[1].filename = "Ferrari Enzo 2.jpg";

            // Ferrari Enzo has no videos

            my_cars[17] = new car();
            my_cars[17].ID = 17;
            my_cars[17].manufacturer = "Toyota";
            my_cars[17].model = "Supra GR";
            my_cars[17].description = "Buy the Dodge.";
            my_cars[17].horsepower = 335;
            my_cars[17].top_speed = 155;
            my_cars[17].zero_to_sixty = 3.8;
            my_cars[17].price = 55250;
            my_cars[17].passed_search = true;
            my_cars[17].pic_count = 1;
            my_cars[17].vid_count = 1;

            my_cars[17].pics[0] = new car_pic();
            my_cars[17].pics[0].ID = 38;
            my_cars[17].pics[0].filename = "toyota GR Supra.jpg";

            my_cars[17].vids[0] = new car_vid();
            my_cars[17].vids[0].ID = 31;
            my_cars[17].vids[0].filename = "Toyota GR Supra v1.mp4";
            my_cars[17].vids[0].thumbnail = "toyota GR Supra thumbnail.jpg";

            my_cars[18] = new car();
            my_cars[18].ID = 17;
            my_cars[18].manufacturer = "Acura";
            my_cars[18].model = "NSX";
            my_cars[18].description = "Beautiful car. This thing will hold that turn at 100+.";
            my_cars[18].horsepower = 573;
            my_cars[18].top_speed = 191;
            my_cars[18].zero_to_sixty = 3.0;
            my_cars[18].price = 157500;
            my_cars[18].passed_search = true;
            my_cars[18].pic_count = 1;
            my_cars[18].vid_count = 0;

            my_cars[18].pics[0] = new car_pic();
            my_cars[18].pics[0].ID = 39;
            my_cars[18].pics[0].filename = "Acura NSX 1.jpg";

            // no Acura NSX vids

            my_cars[19] = new car();
            my_cars[19].ID = 17;
            my_cars[19].manufacturer = "Acura";
            my_cars[19].model = "NSX";
            my_cars[19].description = "Beautiful car. This thing will hold that turn at 100+.";
            my_cars[19].horsepower = 573;
            my_cars[19].top_speed = 191;
            my_cars[19].zero_to_sixty = 3.0;
            my_cars[19].price = 157500;
            my_cars[19].passed_search = true;
            my_cars[19].pic_count = 1;
            my_cars[19].vid_count = 0;

            my_cars[19].pics[0] = new car_pic();
            my_cars[19].pics[0].ID = 40;
            my_cars[19].pics[0].filename = "Acura NSX 2.jpg";
        }
        private void AddSwoosh()
        {
            Image swoosh = Image.FromFile(@"D:\documents\C# From Beginner to Pro\chapter 14 storefront\images\swoosh.jpg");
            Size swoosh_size = new Size(950, 20);
            Size swoosh_size2 = new Size(1250, 20);

            PictureBox pb = new PictureBox();
            pb.Image = swoosh;
            pb.Size = swoosh_size;
            pb.Location = new Point(326,50);
            pb.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb);

            PictureBox pb2 = new PictureBox();
            pb2.Image = swoosh;
            pb2.Size = swoosh_size;
            pb2.Location = new Point(326, 75);
            pb2.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb2);

            PictureBox pb3 = new PictureBox();
            pb3.Image = swoosh;
            pb3.Size = swoosh_size;
            pb3.Location = new Point(326, 100);
            pb3.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb3);

            PictureBox pb4 = new PictureBox();
            pb4.Image = swoosh;
            pb4.Size = swoosh_size2;
            pb4.Location = new Point(0, 125);
            pb4.SizeMode = PictureBoxSizeMode.StretchImage;
            this.Controls.Add(pb4);
        }

        private void AddSearchBar()
        {
            Font myFont = new Font(FontFamily.GenericSansSerif, 14, FontStyle.Bold);

            Label search_label = new Label();
            search_label.Text = "Search:";
            search_label.Font = myFont;
            search_label.Location = new Point(350, 20);

            search_textbox.Size = new Size(500,20);
            search_textbox.Text = "";
            search_textbox.Location = new Point(450, 20);
            search_textbox.Font = myFont;
            search_textbox.BorderStyle = BorderStyle.Fixed3D;

            Label clear_x = new Label();
            clear_x.Text = "X";
            clear_x.AutoSize = true;
            clear_x.Location = new Point(922, 21);
            clear_x.Font = myFont;
            clear_x.BackColor = search_textbox.BackColor;
            clear_x.Click += new EventHandler(ClearSearch); 
                
            Image img = Image.FromFile(@"D:\documents\C# From Beginner to Pro\chapter 14 storefront\images\search icon.jpg");
            PictureBox search_icon = new PictureBox();
            search_icon.Location = new Point(960,20);
            search_icon.Size = new Size(25, 25);
            search_icon.Image = img;
            search_icon.SizeMode = PictureBoxSizeMode.StretchImage;
            search_icon.BorderStyle = BorderStyle.FixedSingle;
            search_icon.Click += new EventHandler(DoSearch);  // we will uncomment when we create the routine

            this.Controls.Add(search_label);
            this.Controls.Add(clear_x); // want the X to appear on top of textbox so add it first
            this.Controls.Add(search_textbox);
            this.Controls.Add(search_icon);
        }

        private void DoSearch(object sender, EventArgs e)
        {
            ClearCars();
            WhichCars();
            DisplayMatches();
        }

        private void AddLogo()
        {
            Image logo = Image.FromFile(@"D:\documents\C# From Beginner to Pro\chapter 14 storefront\images\logo.jpg");
            PictureBox lg = new PictureBox();
            lg.Image = logo;
            lg.Size = new Size(325, 125);
            lg.Location = new Point(0, 0);
            lg.SizeMode = PictureBoxSizeMode.StretchImage;

            // note, we will not add a click handler because we are on the home page
            this.Controls.Add(lg);
        }
    }
}
