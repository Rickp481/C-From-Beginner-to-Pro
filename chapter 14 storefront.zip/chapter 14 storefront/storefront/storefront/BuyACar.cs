﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace storefront
{
    public partial class BuyACar : Form
    {
        public BuyACar()
        {
            InitializeComponent();
        }

        private void BuyACar_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1210, 800);
            this.Text = "Get Buyer Profile";
            PictureBox pb1 = new PictureBox();
            pb1.Size = new Size(1200,790);
            pb1.SizeMode = PictureBoxSizeMode.StretchImage;
            pb1.Location = new Point(10,10);
            Image img = Image.FromFile(@"D:\documents\C# From Beginner to Pro\chapter 14 storefront\cars\buy it form.jpg");
            pb1.Image = img;
            this.Controls.Add(pb1);
        }
    }
}
