﻿using System;
using System.IO;

namespace File_Input_and_Output
{
    class Program
    {
        static void Main(string[] args)
        {

            string mydir;

            // mydir = @"C:\";     
            mydir = @"C:\VS IO Files";     

            try
            {
                Directory.SetCurrentDirectory(mydir);
            }
            catch (DirectoryNotFoundException e)
            {
                Console.WriteLine("The specified directory does not exist {0}", e);
            }

            try
            {
                FileStream f1 = new FileStream("temp.txt", FileMode.OpenOrCreate, FileAccess.ReadWrite);  // open a file named temp.txt for output w/ read & write privs
                for (int lcv = 65; lcv <= 90; lcv++)    // ASCII A - Z
                {
                    f1.WriteByte((byte)lcv);    // cast lcv to a byte and then write it to the f1 file
                }
                f1.Position = 0;    // move steam pointer to position 0; beginning of stream
                for (int lcv = 0; lcv < 26; lcv++)
                {
                    char c1 = (char)f1.ReadByte();  // read a byte from the stream, cast it to a char and store in c1
                    Console.WriteLine(c1);
                }
                f1.Close();
            }
            catch (UnauthorizedAccessException e)
            {
                Console.WriteLine("Unauthorized access exception {0}", e);
            }

            // now go ahead and delete that file, note the File class is static
            if (File.Exists(@"C:\VS IO Files\temp.txt"))
            {
                File.Delete(@"C:\VS IO Files\temp.txt");    // poof - that baby is gone
            }

            Console.ReadLine();

        }
    }
}
