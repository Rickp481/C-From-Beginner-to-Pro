﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Net.Mail;
using System.IO;
using Excel = Microsoft.Office.Interop.Excel;
using System.Runtime.InteropServices;

namespace advanced_file_input_output_techniques
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            this.Size = new Size(1400, 750);
            this.Text = "Send HTML Email with RTP Attachment";

            // we will use a big multiline TextBox to preview email to user
            TextBox tb = new TextBox();
            tb.Size = new Size(1200, 600);
            tb.Location = new Point(150, 50);
            tb.Multiline = true;
            tb.Enabled = false;
            tb.BorderStyle = BorderStyle.Fixed3D;
            tb.BackColor = Color.AliceBlue;
            this.Controls.Add(tb);

            Button b0 = new Button();
            b0.Text = "Display Recipients";
            b0.Size = new Size(100,35);
            b0.Location = new Point(25, 50);
            b0.Click += new EventHandler(DisplayRecipients);
            this.Controls.Add(b0);

            Button b1 = new Button();
            b1.Text = "Preview HTML";
            b1.Size = new Size(100, 35);
            b1.Location = new Point(25, 100);
            b1.Click += new EventHandler(PreviewHTML);
            this.Controls.Add(b1);

            Button b2 = new Button();
            b2.Text = "Read RTF File";
            b2.Size = new Size(100, 35);
            b2.Location = new Point(25, 150);
            b2.Click += new EventHandler(ReadRTF);
            this.Controls.Add(b2);

            Button b3 = new Button();
            b3.Text = "Write RTF File";
            b3.Size = new Size(100, 35);
            b3.Location = new Point(25, 200);
            b3.Click += new EventHandler(WriteRTF);
            this.Controls.Add(b3);

            Button b4 = new Button();
            b4.Text = "Send Email";
            b4.Size = new Size(100, 35);
            b4.Location = new Point(25, 250);
            b4.Click += new EventHandler(SendEmails);
            this.Controls.Add(b4);

            WebBrowser wb = new WebBrowser();
            wb.Size = new Size(1200, 600);
            wb.Location = new Point(150, 50);
            wb.Visible = false;
            this.Controls.Add(wb);

            RichTextBox rtb1 = new RichTextBox();
            rtb1.Size = new Size(1200, 600);
            rtb1.Location = new Point(150, 50);
            rtb1.Visible = false;
            rtb1.Enabled = false; // no user input
            this.Controls.Add(rtb1);
        }

        private void SendEmails(object sender, EventArgs e)
        {
            string my_email = "", my_first = "", my_last = "", dt4 = "", html2 = "";

            // open up our Excel spreadsheet
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"D:\documents\C# From Beginner to Pro\chapter 15 Advanced IO techniques\email list 9-6-2020.xlsx");
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];    // these are 1-based indexed
            Excel.Range xlRange = xlWorksheet.UsedRange;

            // go read our HTML file into local memory
            string html = File.ReadAllText(@"D:\documents\C# From Beginner to Pro\chapter 15 Advanced IO techniques\email 9-6-2020 v1.htm");

            // instantiate the email class
            MailMessage mail = new MailMessage();
            SmtpClient client = new SmtpClient("smtp.gmail.com");
            client.Port = 587;
            client.Credentials = new System.Net.NetworkCredential("rickp481@gmail.com", "Man4Mary1612");
            client.EnableSsl = true;

            Attachment att1 = new Attachment(@"D:\documents\C# From Beginner to Pro\chapter 15 Advanced IO techniques\attach1.rtf");

            foreach (Control c in this.Controls)
            {
                if (c is WebBrowser)
                {
                    WebBrowser wb1 = (WebBrowser)c;
                    wb1.Visible = false;
                }
                else if (c is RichTextBox)
                {
                    RichTextBox rtb1 = (RichTextBox)c;
                    rtb1.Visible = false;
                }
                else if (c is TextBox)
                {
                    TextBox tb1 = (TextBox)c;
                    tb1.Visible = true;
                    tb1.Text = "Recipients" + Environment.NewLine + Environment.NewLine;

                    // read the spreadsheet to get our mail merge information
                    for (int i = 2; i <= xlRange.Rows.Count; i++)
                    {
                        for (int j = 1; j <= xlRange.Columns.Count; j++)
                        {
                            if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 1)
                            {
                                mail.To.Add(xlRange.Cells[i, j].Value2.ToString());
                                my_email = xlRange.Cells[i, j].Value2.ToString();
                            }
                            else if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 2)
                            {
                                my_first = xlRange.Cells[i, j].Value2.ToString();
                            }
                            else if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 3)
                            {
                                my_last = xlRange.Cells[i, j].Value2.ToString();
                            }
                            else if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 4)
                            {
                                string dt = xlRange.Cells[i, j].Value2.ToString();
                                double dt2 = double.Parse(dt);
                                var dt3 = DateTime.FromOADate(dt2).ToString("MMMM dd, yyyy");
                                dt4 = dt3.ToString();
                            }

                        }
                    }

                    // do the mail merge via Replace method
                    html2 = html.Replace("{email}", my_email).Replace("{first_name}", my_first).Replace("{last_name}", my_last).Replace("{sub_date}", dt4);

                    // mail it
                    mail.From = new MailAddress("vmsmentors@gmail.com");
                    mail.Subject = "Vent Mentor Solution Update";
                    mail.Body = html2;
                    mail.IsBodyHtml = true;
                    mail.Attachments.Add(att1);

                    client.Send(mail);

                    // keep the textbox up to date with recipients
                    tb1.Text += my_email + Environment.NewLine;

                    html2 = "";
                }

                GC.Collect();   // garbage collection 
                GC.WaitForPendingFinalizers();
                Marshal.ReleaseComObject(xlRange);
                Marshal.ReleaseComObject(xlWorksheet);
                xlWorkbook.Close();
                Marshal.ReleaseComObject(xlWorkbook);
                xlApp.Quit();   // why is this Method a quit vs close
                Marshal.ReleaseComObject(xlApp);
            }
        }

            private void WriteRTF(object sender, EventArgs e)
        {
            MemoryStream rtf_content = new MemoryStream();
            SaveFileDialog sf1 = new SaveFileDialog();
            Stream myFileStream;

            sf1.CreatePrompt = true;    // create if does not exist
            sf1.OverwritePrompt = true;

            foreach (Control c in this.Controls)
            {
                if (c is RichTextBox)
                {
                    RichTextBox rtb1 = (RichTextBox)c;

                    // save the contents of our RichTextBox to a local memory stream object
                    rtb1.SaveFile(rtf_content, RichTextBoxStreamType.PlainText);
                    rtf_content.WriteByte(13); // add hard line feed

                    // now save it out to a file via the SaveFileDialog
                    sf1.FileName = "myText"; // default
                    sf1.DefaultExt = "txt"; // only used if the user has All Files specified
                    sf1.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
                    sf1.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);

                    // put up the dialog and harvest result
                    DialogResult myResult = sf1.ShowDialog();
                    if (myResult == DialogResult.OK)
                    {
                        myFileStream = sf1.OpenFile();  // create or truncate
                        rtf_content.Position = 0;  // rewind the content pointer
                        rtf_content.WriteTo(myFileStream);  // write stream to file
                        myFileStream.Close();
                    }
                }
            }
        }

        private void ReadRTF(object sender, EventArgs e)
        {
            OpenFileDialog openFile1 = new OpenFileDialog();
            openFile1.DefaultExt = "*.rtf";
            openFile1.Filter = "RTF Files|*.rtf";

            if (openFile1.ShowDialog() == System.Windows.Forms.DialogResult.OK && openFile1.FileName.Length > 0)
            {
                foreach (Control c in this.Controls)
                {
                    if (c is WebBrowser)
                    {
                        WebBrowser wb1 = (WebBrowser)c;
                        wb1.Visible = false;
                    }
                    else if (c is TextBox)
                    {
                        TextBox tb1 = (TextBox)c;
                        tb1.Visible = false;
                    }
                    else if (c is RichTextBox)
                    {
                        RichTextBox rtb1 = (RichTextBox)c;
                        rtb1.LoadFile(openFile1.FileName);
                        rtb1.Visible = true;
                    }
                }
            }
        }

        private void PreviewHTML(object sender, EventArgs e)
        {
            foreach (Control c in this.Controls)
            {
                if (c is TextBox)
                {
                    TextBox tb1 = (TextBox)c;
                    tb1.Visible = false;
                }
                else if (c is RichTextBox)
                {
                    RichTextBox rtb1 = (RichTextBox)c;
                    rtb1.Visible = false;
                }
                else if (c is WebBrowser)
                {
                    WebBrowser wb1 = (WebBrowser)c;
                    wb1.Visible = true;
                    wb1.Navigate(new Uri(@"file://D:\documents\C# From Beginner to Pro\chapter 15 Advanced IO techniques\email 9-6-2020 v1.htm"));
                }
            }
        }
        private void DisplayRecipients(object sender, EventArgs e)
        {
            // open an Excel spreadsheet
            Excel.Application xlApp = new Excel.Application();
            Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"D:\documents\C# From Beginner to Pro\chapter 15 Advanced IO techniques\email list 9-6-2020.xlsx");
            Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[1];    // these are 1-based indexed
            Excel.Range xlRange = xlWorksheet.UsedRange;

            foreach (Control c in this.Controls)
            {
                if (c is WebBrowser)
                {
                    WebBrowser wb1 = (WebBrowser)c;
                    wb1.Visible = false;
                }
                else if (c is RichTextBox)
                {
                    RichTextBox rtb1 = (RichTextBox)c;
                    rtb1.Visible = false;
                }
                else if (c is TextBox)
                {
                    TextBox tb1 = (TextBox)c;
                    tb1.Visible = true;
                    tb1.Text = "Recipients" + Environment.NewLine + Environment.NewLine;

                    for (int i=2; i <= xlRange.Rows.Count; i++) // for all occupied rows except header (remember 1-based indexes
                    {
                        for (int j=1; j <= xlRange.Columns.Count; j++)  // for all occupied columns
                        {
                            if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 1)  // email address is populated
                                tb1.Text = tb1.Text + xlRange.Cells[i, j].Value2.ToString() + " ";
                            else if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 2)  // first name is populated
                                tb1.Text = tb1.Text + xlRange.Cells[i, j].Value2.ToString() + " ";
                            else if (xlRange.Cells[i, j] != null && xlRange.Cells[i, j].Value2 != null && j == 3)  // last name is populated
                                tb1.Text = tb1.Text + xlRange.Cells[i, j].Value2.ToString() + " " + Environment.NewLine;
                        }
                    }
                }
            }

            GC.Collect();   // garbage collection on COM objects is manual
            GC.WaitForPendingFinalizers();
            Marshal.ReleaseComObject(xlRange);
            Marshal.ReleaseComObject(xlWorksheet);
            xlWorkbook.Close();
            Marshal.ReleaseComObject(xlWorkbook);
            xlApp.Quit();
            Marshal.ReleaseComObject(xlApp);

        }
    }
}
